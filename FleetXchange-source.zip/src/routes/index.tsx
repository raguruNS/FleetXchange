import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Bus, Truck, Wrench, Search, ShieldCheck, MessageSquare, BadgeCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { ListingGrid } from "@/components/site/ListingGrid";
import { CARD_COLS, type ListingRow } from "@/components/site/ListingCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FleetXchange — Used Buses, Trucks & Spare Parts in India" },
      { name: "description", content: "Buy and sell used buses, trucks and commercial vehicle spare parts from verified sellers across India." },
      { property: "og:title", content: "FleetXchange — Used Buses, Trucks & Spare Parts" },
      { property: "og:description", content: "Verified sellers. Direct chat. Buses, trucks and spare parts across India." },
    ],
  }),
  component: Home,
});

function Home() {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const latest = useQuery({
    queryKey: ["latest"],
    queryFn: async () => (await supabase.from("listings").select(CARD_COLS).eq("status", "active").order("tier", { ascending: true }).order("created_at", { ascending: false }).limit(12)).data ?? [],
  });
  const cats = [
    { label: "Buses", icon: Bus, search: { kind: "vehicle" as const, vt: "bus" as const } },
    { label: "Trucks", icon: Truck, search: { kind: "vehicle" as const, vt: "truck" as const } },
    { label: "Spare Parts", icon: Wrench, search: { kind: "part" as const } },
  ];
  return (
    <>
      <section className="bg-hero text-secondary-foreground">
        <div className="mx-auto max-w-7xl px-4 py-16 md:py-24">
          <h1 className="max-w-3xl text-4xl font-extrabold md:text-6xl">Buy & sell commercial vehicles <span className="text-primary">without middlemen.</span></h1>
          <p className="mt-4 max-w-xl text-lg opacity-80">Used buses, trucks and genuine spare parts from mobile-verified sellers across India.</p>
          <form onSubmit={(e) => { e.preventDefault(); navigate({ to: "/browse", search: { q } }); }} className="mt-8 flex max-w-2xl gap-2">
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search Tata 1512, Volvo 9400, brake pads…" className="h-12 bg-card text-foreground" />
            <Button type="submit" size="lg" className="h-12"><Search className="h-4 w-4" />Search</Button>
          </form>
          <div className="mt-8 grid max-w-2xl grid-cols-3 gap-3">
            {cats.map((c) => (
              <Link key={c.label} to="/browse" search={c.search} className="flex flex-col items-center gap-2 rounded-lg border border-sidebar-border bg-sidebar-accent/60 p-4 font-semibold hover:border-primary">
                <c.icon className="h-7 w-7 text-primary" />{c.label}
              </Link>
            ))}
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-2xl font-bold">Latest listings</h2>
          <Link to="/browse" className="text-sm font-medium text-primary">View all →</Link>
        </div>
        {latest.isLoading ? <div className="text-muted-foreground">Loading…</div> : <ListingGrid rows={latest.data as ListingRow[]} empty="No listings yet — be the first to sell!" />}
      </section>
      <section className="mx-auto grid max-w-7xl gap-4 px-4 sm:grid-cols-3">
        {[
          { i: BadgeCheck, t: "Verified sellers", d: "Every seller verifies email and mobile number before posting." },
          { i: MessageSquare, t: "Direct chat", d: "Talk to sellers in-app. No brokers, no commission." },
          { i: ShieldCheck, t: "Report & moderation", d: "Suspicious listings are reviewed and removed by our team." },
        ].map((f) => (
          <div key={f.t} className="rounded-lg border bg-card p-5"><f.i className="h-6 w-6 text-primary" /><h3 className="mt-3 font-bold">{f.t}</h3><p className="text-sm text-muted-foreground">{f.d}</p></div>
        ))}
      </section>
    </>
  );
}
