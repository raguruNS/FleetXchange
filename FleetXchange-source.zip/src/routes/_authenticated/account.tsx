import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/auth";
import { changePhone, deleteMyAccount, sendPhoneOtp, verifyPhoneOtp } from "@/lib/account.functions";
import { PASSWORD_RULES, isStrongPassword, maskPhone } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [{ title: "My account — FleetXchange" }, { name: "description", content: "Manage your profile, verification and security." }] }),
  component: Account,
});

function Account() {
  const { user, profile, refetch, isAdmin } = useProfile();
  const navigate = useNavigate();
  const [p, setP] = useState({ full_name: "", location: "", bio: "", show_phone: true, email_notifications: true });
  useEffect(() => { if (profile) setP({ full_name: profile.full_name ?? "", location: profile.location ?? "", bio: profile.bio ?? "", show_phone: profile.show_phone, email_notifications: profile.email_notifications }); }, [profile]);

  const sendOtp = useServerFn(sendPhoneOtp);
  const verifyOtp = useServerFn(verifyPhoneOtp);
  const setPhone = useServerFn(changePhone);
  const del = useServerFn(deleteMyAccount);
  const [phone, setPhoneInput] = useState("");
  const [code, setCode] = useState("");
  const [cooldown, setCooldown] = useState(0);
  const [otpSent, setOtpSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pw, setPw] = useState({ current: "", next: "" });
  useEffect(() => { if (cooldown <= 0) return; const t = setTimeout(() => setCooldown((c) => c - 1), 1000); return () => clearTimeout(t); }, [cooldown]);

  const run = async (fn: () => Promise<unknown>) => { setBusy(true); try { await fn(); } catch (e) { toast.error((e as Error).message); } setBusy(false); };

  if (!profile) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;

  return (
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-8">
      <h1 className="text-3xl font-extrabold">My account</h1>

      <Section title="Verification">
        <Row ok={!!user?.email_confirmed_at} label={`Email: ${profile.email ?? user?.email}`} />
        <Row ok={profile.phone_verified} label={`Mobile: ${profile.phone ? maskPhone(profile.phone) : "not added"}`} />
        {!profile.phone_verified && (
          <div className="mt-4 space-y-3 rounded-md bg-muted p-4">
            <p className="text-sm">Verify your mobile number to post listings and chat with sellers.</p>
            <div className="flex gap-2">
              <Input placeholder="10-digit mobile number" value={phone} onChange={(e) => setPhoneInput(e.target.value)} />
              <Button variant="outline" disabled={busy || !phone} onClick={() => run(async () => { await setPhone({ data: { phone } }); await refetch(); setOtpSent(false); toast.success("Mobile number saved"); })}>{profile.phone ? "Change" : "Save"}</Button>
            </div>
            {profile.phone && (
              <div className="flex flex-wrap gap-2">
                <Button disabled={busy || cooldown > 0} onClick={() => run(async () => {
                  const r = await sendOtp();
                  if (r.alreadyVerified) { await refetch(); return; }
                  setCooldown(r.cooldown);
                  if (r.ok) { setOtpSent(true); toast.success(`OTP sent to ${maskPhone(profile.phone)}`); } else toast.error(`Please wait ${r.cooldown}s before resending.`);
                })}>{cooldown > 0 ? `Resend in ${cooldown}s` : otpSent ? "Resend OTP" : "Send OTP"}</Button>
                {otpSent && (
                  <>
                    <Input className="w-36" inputMode="numeric" maxLength={6} placeholder="6-digit OTP" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
                    <Button disabled={busy || code.length !== 6} onClick={() => run(async () => { await verifyOtp({ data: { code } }); await refetch(); toast.success("Mobile number verified!"); })}>Verify</Button>
                  </>
                )}
              </div>
            )}
          </div>
        )}
      </Section>

      <Section title="Profile">
        <div className="grid gap-3">
          <F label="Full name"><Input value={p.full_name} onChange={(e) => setP({ ...p, full_name: e.target.value })} /></F>
          <F label="Location"><Input value={p.location} onChange={(e) => setP({ ...p, location: e.target.value })} /></F>
          <F label="About"><Textarea value={p.bio} onChange={(e) => setP({ ...p, bio: e.target.value })} /></F>
          <label className="flex items-center justify-between text-sm">Show my phone to logged-in buyers<Switch checked={p.show_phone} onCheckedChange={(v) => setP({ ...p, show_phone: v })} /></label>
          <label className="flex items-center justify-between text-sm">Email notifications<Switch checked={p.email_notifications} onCheckedChange={(v) => setP({ ...p, email_notifications: v })} /></label>
          <Button className="justify-self-end" disabled={busy} onClick={() => run(async () => {
            if (!p.full_name.trim()) throw new Error("Name is required.");
            const { error } = await supabase.from("profiles").update({ ...p, full_name: p.full_name.trim() }).eq("id", profile.id);
            if (error) throw error; await refetch(); toast.success("Profile saved");
          })}>Save profile</Button>
        </div>
      </Section>

      <Section title="Change password">
        <div className="grid gap-3">
          <F label="Current password"><Input type="password" value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} /></F>
          <F label="New password"><Input type="password" value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} /></F>
          <ul className="text-xs">{PASSWORD_RULES.map((r) => <li key={r.label} className={r.test(pw.next) ? "text-success" : "text-muted-foreground"}>• {r.label}</li>)}</ul>
          <Button className="justify-self-end" disabled={busy || !isStrongPassword(pw.next) || !pw.current} onClick={() => run(async () => {
            const { error } = await supabase.auth.updateUser({ password: pw.next, current_password: pw.current } as any);
            if (error) throw error; setPw({ current: "", next: "" }); toast.success("Password changed");
          })}>Update password</Button>
        </div>
      </Section>

      {!isAdmin && <ClaimAdmin onDone={refetch} />}

      <Section title="Danger zone">
        <Button variant="destructive" disabled={busy} onClick={() => confirm("Permanently delete your account and all listings?") && run(async () => {
          await del(); await supabase.auth.signOut(); navigate({ to: "/" }); toast.success("Account deleted");
        })}>Delete my account</Button>
      </Section>
    </div>
  );
}

function ClaimAdmin({ onDone }: { onDone: () => unknown }) {
  const [hidden, setHidden] = useState(false);
  if (hidden) return null;
  return (
    <p className="text-xs text-muted-foreground">
      Setting up the site? <button className="underline" onClick={async () => {
        const { data } = await supabase.rpc("claim_first_admin");
        if (data) { toast.success("You are now the admin."); onDone(); } else toast.error("An admin already exists.");
        setHidden(true);
      }}>Claim admin access</button> (only works if no admin exists yet).
    </p>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="rounded-lg border bg-card p-5"><h2 className="mb-4 font-bold">{title}</h2>{children}</section>;
}
function F({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1"><Label className="text-xs text-muted-foreground">{label}</Label>{children}</div>;
}
function Row({ ok, label }: { ok: boolean; label: string }) {
  return <div className="flex items-center gap-2 py-1 text-sm">{ok ? <BadgeCheck className="h-4 w-4 text-success" /> : <AlertTriangle className="h-4 w-4 text-destructive" />}{label}<span className={ok ? "text-success" : "text-destructive"}>{ok ? "Verified" : "Not verified"}</span></div>;
}
