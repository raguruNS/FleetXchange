import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { useSignedUrls } from "@/lib/images";
import { CARD_COLS, firstPath, type ListingRow } from "@/components/site/ListingCard";
import { formatINR } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/my-listings")({
  head: () => ({ meta: [{ title: "My listings — FleetXchange" }, { name: "description", content: "Manage your listings on FleetXchange." }] }),
  component: MyListings,
});

function MyListings() {
  const { user } = useSession();
  const q = useQuery({
    queryKey: ["my-listings", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("listings").select(CARD_COLS + ", removed_by_admin").eq("seller_id", user!.id).neq("status", "removed").order("created_at", { ascending: false })).data as unknown as (ListingRow & { removed_by_admin: boolean })[] ?? [],
  });
  const urls = useSignedUrls((q.data ?? []).map(firstPath));
  const setStatus = async (id: string, status: "active" | "sold" | "removed" | "draft") => {
    const { error } = await supabase.from("listings").update({ status, sold_at: status === "sold" ? new Date().toISOString() : null }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Updated"); q.refetch();
  };
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between"><h1 className="text-2xl font-bold">My listings</h1><Button asChild><Link to="/sell">New listing</Link></Button></div>
      {q.isLoading ? <p className="text-muted-foreground">Loading…</p> : !q.data?.length ? (
        <div className="rounded-lg border border-dashed p-10 text-center text-muted-foreground">You haven't posted anything yet.</div>
      ) : (
        <div className="space-y-3">
          {q.data.map((l) => (
            <div key={l.id} className="flex flex-wrap items-center gap-4 rounded-lg border bg-card p-3">
              <div className="h-20 w-28 overflow-hidden rounded bg-muted">{urls[firstPath(l) ?? ""] && <img src={urls[firstPath(l)!]} alt="" className="h-full w-full object-cover" />}</div>
              <div className="min-w-0 flex-1">
                <Link to="/listing/$id" params={{ id: l.id }} className="font-semibold hover:underline">{l.title}</Link>
                <div className="text-sm text-primary">{formatINR(l.price)}</div>
                <Badge variant={l.status === "active" ? "default" : "secondary"} className="mt-1 capitalize">{l.status}</Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" asChild><Link to="/sell" search={{ edit: l.id }}>Edit</Link></Button>
                {l.status === "active" && <Button size="sm" variant="outline" onClick={() => setStatus(l.id, "sold")}>Mark sold</Button>}
                {l.status !== "active" && <Button size="sm" variant="outline" onClick={() => setStatus(l.id, "active")}>Republish</Button>}
                <Button size="sm" variant="destructive" onClick={() => confirm("Delete this listing?") && setStatus(l.id, "removed")}>Delete</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
