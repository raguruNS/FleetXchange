import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { X, Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/auth";
import { imagesOf, uploadImage, useSignedUrls } from "@/lib/images";
import {
  AXLES, BUS_AC, BUS_BODY, FUEL_TYPES, INDIAN_STATES, PART_CATEGORIES, PART_IMAGE_LABELS, TRANSMISSIONS,
  TRUCK_BODY, VEHICLE_BRANDS, VEHICLE_IMAGE_LABELS, type ListingImage,
} from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/sell")({
  validateSearch: (s) => z.object({ edit: z.string().optional() }).parse(s),
  head: () => ({ meta: [{ title: "Sell — FleetXchange" }, { name: "description", content: "Post a bus, truck or spare part." }] }),
  component: Sell,
});

type Form = Record<string, string>;
const sel = "h-9 w-full rounded-md border border-input bg-card px-2 text-sm";
const MAX_IMAGES = 12;

function Sell() {
  const { edit } = Route.useSearch();
  const { user, profile, loading } = useProfile();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [f, setF] = useState<Form>({ kind: "vehicle", vehicle_type: "bus", tier: "standard", part_condition: "used" });
  const [specs, setSpecs] = useState<Form>({});
  const [images, setImages] = useState<ListingImage[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const urls = useSignedUrls(images.map((i) => i.path));

  const existing = useQuery({
    queryKey: ["edit-listing", edit],
    enabled: !!edit,
    queryFn: async () => (await supabase.from("listings").select("*").eq("id", edit!).maybeSingle()).data,
  });
  useEffect(() => {
    const l = existing.data;
    if (!l) return;
    const s: Form = {};
    Object.entries(l).forEach(([k, v]) => { if (v != null && typeof v !== "object") s[k] = String(v); });
    setF(s);
    setSpecs((l.specs as Form) ?? {});
    setImages(imagesOf(l.images));
  }, [existing.data]);

  if (loading) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!profile?.phone_verified) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold">Verify your mobile number to sell</h1>
        <p className="mt-2 text-muted-foreground">For buyer safety, only sellers with a verified mobile number can post listings.</p>
        <Button asChild className="mt-6"><Link to="/account">Verify now</Link></Button>
      </div>
    );
  }

  const set = (k: string, v: string) => setF((p) => ({ ...p, [k]: v }));
  const isPart = f["kind"] === "part";
  const labels = isPart ? PART_IMAGE_LABELS : VEHICLE_IMAGE_LABELS;

  async function onFiles(files: FileList | null) {
    if (!files || !user) return;
    const list = Array.from(files).slice(0, MAX_IMAGES - images.length);
    setUploading(true);
    try {
      for (const file of list) {
        const path = await uploadImage(user.id, file);
        setImages((p) => [...p, { path, url: "", label: labels[Math.min(p.length, labels.length - 1)] ?? "Other" }]);
      }
    } catch (e) { toast.error((e as Error).message); }
    setUploading(false);
  }

  async function save(status: "active" | "draft"): Promise<void> {
    if (!f["title"]?.trim()) { toast.error("Title is required."); return; }
    if (!f["price"] || +f["price"] <= 0) { toast.error("Enter a valid price."); return; }
    if (status === "active" && images.length === 0) { toast.error("Add at least one photo."); return; }
    if (!f["state"] || !f["city"]) { toast.error("State and city are required."); return; }
    const num = (k: string) => (f[k] ? Number(f[k]) : null);
    const str = (k: string) => f[k]?.trim() || null;
    const row = {
      kind: f["kind"] as "vehicle" | "part",
      vehicle_type: isPart ? null : (f["vehicle_type"] as "bus" | "truck"),
      tier: (isPart ? "standard" : f["tier"]) as "standard" | "premium",
      part_condition: isPart ? (f["part_condition"] as "new" | "used") : null,
      part_category: isPart ? str("part_category") : null,
      title: f["title"].trim(), brand: str("brand"), model: str("model"),
      mfg_year: num("mfg_year"), reg_year: num("reg_year"), price: Number(f["price"]),
      km: isPart ? null : num("km"), fuel: isPart ? null : str("fuel"), transmission: isPart ? null : str("transmission"),
      owners: isPart ? null : num("owners"),
      part_number: isPart ? str("part_number") : null, compat_vehicle_type: isPart ? str("compat_vehicle_type") : null,
      compat_brand: isPart ? str("compat_brand") : null, compat_model: isPart ? str("compat_model") : null,
      compat_year: isPart ? str("compat_year") : null, quantity: isPart ? num("quantity") : null,
      state: str("state"), city: str("city"), area: str("area"), description: str("description"),
      specs: isPart ? {} : specs, images, status,
    };
    setSaving(true);
    const res = edit
      ? await supabase.from("listings").update(row).eq("id", edit).select("id").single()
      : await supabase.from("listings").insert(row).select("id").single();
    setSaving(false);
    if (res.error) { toast.error(res.error.message); return; }
    qc.invalidateQueries();
    toast.success(status === "draft" ? "Saved as draft" : edit ? "Listing updated" : "Listing published");
    navigate({ to: status === "active" ? "/listing/$id" : "/my-listings", params: { id: res.data.id } as any });
  }

  const T = (k: string, label: string, type = "text") => (
    <Field label={label}><Input type={type} value={f[k] ?? ""} onChange={(e) => set(k, e.target.value)} /></Field>
  );
  const S = (k: string, label: string, opts: string[], target: "f" | "s" = "f") => (
    <Field label={label}>
      <select className={sel} value={(target === "f" ? f[k] : specs[k]) ?? ""} onChange={(e) => target === "f" ? set(k, e.target.value) : setSpecs((p) => ({ ...p, [k]: e.target.value }))}>
        <option value="">Select</option>{opts.map((o) => <option key={o}>{o}</option>)}
      </select>
    </Field>
  );
  const SpecT = (k: string, label: string) => (
    <Field label={label}><Input value={specs[k] ?? ""} onChange={(e) => setSpecs((p) => ({ ...p, [k]: e.target.value }))} /></Field>
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-3xl font-extrabold">{edit ? "Edit listing" : "Sell on FleetXchange"}</h1>
      <div className="mt-6 space-y-6">
        <Card title="What are you selling?">
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Category">
              <select className={sel} value={isPart ? "part" : f["vehicle_type"]} disabled={!!edit} onChange={(e) => {
                const v = e.target.value; v === "part" ? set("kind", "part") : setF((p) => ({ ...p, kind: "vehicle", vehicle_type: v }));
              }}><option value="bus">Bus</option><option value="truck">Truck</option><option value="part">Spare part</option></select>
            </Field>
            {isPart
              ? <Field label="Condition"><select className={sel} value={f["part_condition"]} onChange={(e) => set("part_condition", e.target.value)}><option value="new">New</option><option value="used">Used</option></select></Field>
              : <Field label="Tier"><select className={sel} value={f["tier"]} onChange={(e) => set("tier", e.target.value)}><option value="standard">Standard</option><option value="premium">Premium</option></select></Field>}
            {isPart && S("part_category", "Part category", PART_CATEGORIES)}
          </div>
        </Card>
        <Card title="Details">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="sm:col-span-2">{T("title", "Title *")}</div>
            {S("brand", "Brand", VEHICLE_BRANDS)}
            {T("model", "Model")}
            {T("price", "Price (₹) *", "number")}
            {isPart ? (
              <>{T("part_number", "Part number")}{T("quantity", "Quantity", "number")}
                {S("compat_vehicle_type", "Fits vehicle type", ["Bus", "Truck", "Both"])}
                {S("compat_brand", "Fits brand", VEHICLE_BRANDS)}{T("compat_model", "Fits model(s)")}{T("compat_year", "Fits years (e.g. 2015-2020)")}</>
            ) : (
              <>{T("mfg_year", "Manufacturing year", "number")}{T("reg_year", "Registration year", "number")}
                {T("km", "KM driven", "number")}{S("fuel", "Fuel", FUEL_TYPES)}{S("transmission", "Transmission", TRANSMISSIONS)}
                {T("owners", "No. of owners", "number")}</>
            )}
          </div>
        </Card>
        {!isPart && (
          <Card title="Specifications">
            <div className="grid gap-3 sm:grid-cols-3">
              {f["vehicle_type"] === "bus" ? (
                <>{SpecT("seats", "Seating capacity")}{S("ac", "AC", BUS_AC, "s")}{S("body", "Body type", BUS_BODY, "s")}</>
              ) : (
                <>{SpecT("payload", "Payload (tons)")}{S("body", "Body type", TRUCK_BODY, "s")}{S("axle", "Axle", AXLES, "s")}</>
              )}
              {SpecT("engine", "Engine (HP / CC)")}{SpecT("tyres", "Tyre condition")}{SpecT("insurance", "Insurance valid till")}
              {SpecT("fitness", "Fitness valid till")}{SpecT("permit", "Permit")}{SpecT("rc", "RC status")}
            </div>
          </Card>
        )}
        <Card title="Location">
          <div className="grid gap-3 sm:grid-cols-3">{S("state", "State *", INDIAN_STATES)}{T("city", "City *")}{T("area", "Area")}</div>
        </Card>
        <Card title={`Photos (${images.length}/${MAX_IMAGES})`}>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {images.map((im, i) => (
              <div key={im.path} className="overflow-hidden rounded-md border bg-muted">
                <div className="relative aspect-[4/3]">
                  {urls[im.path] && <img src={urls[im.path]} alt={im.label} className="h-full w-full object-cover" />}
                  <button type="button" aria-label="Remove photo" onClick={() => setImages((p) => p.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-card p-1"><X className="h-3 w-3" /></button>
                  {i === 0 && <span className="absolute left-1 top-1 rounded bg-primary px-1.5 text-xs text-primary-foreground">Cover</span>}
                </div>
                <select className="w-full border-t bg-card p-1 text-xs" value={im.label} onChange={(e) => setImages((p) => p.map((x, j) => j === i ? { ...x, label: e.target.value } : x))}>
                  {labels.map((l) => <option key={l}>{l}</option>)}
                </select>
              </div>
            ))}
            {images.length < MAX_IMAGES && (
              <label className="grid aspect-[4/3] cursor-pointer place-items-center rounded-md border-2 border-dashed text-sm text-muted-foreground hover:border-primary">
                <span className="flex flex-col items-center gap-1">{uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Upload className="h-5 w-5" />}{uploading ? "Uploading…" : "Add photos"}</span>
                <input type="file" accept="image/*" multiple className="hidden" disabled={uploading} onChange={(e) => { onFiles(e.target.files); e.target.value = ""; }} />
              </label>
            )}
          </div>
        </Card>
        <Card title="Description">
          <Textarea rows={5} value={f["description"] ?? ""} onChange={(e) => set("description", e.target.value)} placeholder="Condition, service history, reason for selling…" />
        </Card>
        <div className="flex flex-wrap justify-end gap-2">
          <Button variant="outline" disabled={saving || uploading} onClick={() => save("draft")}>Save draft</Button>
          <Button disabled={saving || uploading} onClick={() => save("active")}>{saving && <Loader2 className="h-4 w-4 animate-spin" />}{edit ? "Save & publish" : "Publish listing"}</Button>
        </div>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="rounded-lg border bg-card p-5"><h2 className="mb-4 font-bold">{title}</h2>{children}</section>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1"><Label className="text-xs text-muted-foreground">{label}</Label>{children}</div>;
}
