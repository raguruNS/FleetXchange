import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/auth";
import { adminListReports, adminListUsers, adminSetBlocked, adminStats } from "@/lib/admin.functions";
import { formatINR, REPORT_REASONS } from "@/lib/constants";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin panel — FleetXchange" }, { name: "description", content: "Moderate users, listings and reports." }] }),
  component: Admin,
});

function Admin() {
  const { isAdmin, loading } = useProfile();
  if (loading) return <div className="p-10 text-center text-muted-foreground">Loading…</div>;
  if (!isAdmin) return <div className="p-10 text-center">You don't have access to this page.</div>;
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-3xl font-extrabold">Admin panel</h1>
      <Tabs defaultValue="stats">
        <TabsList><TabsTrigger value="stats">Dashboard</TabsTrigger><TabsTrigger value="users">Users</TabsTrigger><TabsTrigger value="listings">Listings</TabsTrigger><TabsTrigger value="reports">Reports</TabsTrigger></TabsList>
        <TabsContent value="stats"><Stats /></TabsContent>
        <TabsContent value="users"><Users /></TabsContent>
        <TabsContent value="listings"><Listings /></TabsContent>
        <TabsContent value="reports"><Reports /></TabsContent>
      </Tabs>
    </div>
  );
}

function Stats() {
  const fn = useServerFn(adminStats);
  const q = useQuery({ queryKey: ["admin-stats"], queryFn: () => fn() });
  const d = q.data;
  if (!d) return <p className="text-muted-foreground">Loading…</p>;
  const items: [string, number][] = [["Users", d.users], ["Mobile verified", d.verified], ["Buses", d.buses], ["Premium buses", d.pBuses], ["Trucks", d.trucks], ["Premium trucks", d.pTrucks], ["Spare parts", d.parts], ["New parts", d.newParts], ["Used parts", d.usedParts], ["Active listings", d.active], ["Sold", d.sold], ["Reports", d.reports], ["Pending reports", d.pending]];
  return <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{items.map(([l, v]) => <div key={l} className="rounded-lg border bg-card p-4"><div className="text-xs text-muted-foreground">{l}</div><div className="font-display text-2xl font-bold">{v}</div></div>)}</div>;
}

function Users() {
  const list = useServerFn(adminListUsers);
  const block = useServerFn(adminSetBlocked);
  const [s, setS] = useState("");
  const [search, setSearch] = useState("");
  const q = useQuery({ queryKey: ["admin-users", search], queryFn: () => list({ data: { search } }) });
  return (
    <div className="space-y-3">
      <form onSubmit={(e) => { e.preventDefault(); setSearch(s); }} className="flex max-w-md gap-2"><Input value={s} onChange={(e) => setS(e.target.value)} placeholder="Name, email or phone" /><Button type="submit">Search</Button></form>
      <div className="overflow-x-auto rounded-lg border bg-card">
        <table className="w-full text-sm">
          <thead className="bg-muted text-left"><tr><th className="p-2">Name</th><th className="p-2">Email</th><th className="p-2">Phone</th><th className="p-2">Status</th><th className="p-2" /></tr></thead>
          <tbody>{q.data?.map((u) => (
            <tr key={u.id} className="border-t">
              <td className="p-2">{u.full_name || "—"} {u.is_admin && <Badge>Admin</Badge>}</td><td className="p-2">{u.email}</td>
              <td className="p-2">{u.phone ?? "—"} {u.phone_verified && <Badge variant="secondary">verified</Badge>}</td>
              <td className="p-2">{u.is_blocked ? <Badge variant="destructive">Blocked</Badge> : "Active"}</td>
              <td className="p-2 text-right">{!u.is_admin && <Button size="sm" variant={u.is_blocked ? "outline" : "destructive"} onClick={async () => {
                try { await block({ data: { userId: u.id, blocked: !u.is_blocked } }); q.refetch(); } catch (e) { toast.error((e as Error).message); }
              }}>{u.is_blocked ? "Unblock" : "Block"}</Button>}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
    </div>
  );
}

function Listings() {
  const q = useQuery({
    queryKey: ["admin-listings"],
    queryFn: async () => (await supabase.from("listings").select("id, title, price, status, kind, vehicle_type, suspicious, removed_by_admin, created_at").order("created_at", { ascending: false }).limit(300)).data ?? [],
  });
  const upd = async (id: string, patch: { suspicious?: boolean; status?: "active" | "removed"; removed_by_admin?: boolean }) => {
    const { error } = await supabase.from("listings").update(patch).eq("id", id);
    if (error) toast.error(error.message); else q.refetch();
  };
  return (
    <div className="overflow-x-auto rounded-lg border bg-card">
      <table className="w-full text-sm">
        <thead className="bg-muted text-left"><tr><th className="p-2">Title</th><th className="p-2">Type</th><th className="p-2">Price</th><th className="p-2">Status</th><th className="p-2" /></tr></thead>
        <tbody>{q.data?.map((l) => (
          <tr key={l.id} className="border-t">
            <td className="p-2"><Link to="/listing/$id" params={{ id: l.id }} className="hover:underline">{l.title}</Link> {l.suspicious && <Badge variant="destructive">Suspicious</Badge>}</td>
            <td className="p-2 capitalize">{l.vehicle_type ?? l.kind}</td><td className="p-2">{formatINR(l.price)}</td>
            <td className="p-2 capitalize">{l.status}{l.removed_by_admin && " (by admin)"}</td>
            <td className="flex justify-end gap-2 p-2">
              <Button size="sm" variant="outline" onClick={() => upd(l.id, { suspicious: !l.suspicious })}>{l.suspicious ? "Unflag" : "Flag"}</Button>
              {l.status === "removed" ? <Button size="sm" variant="outline" onClick={() => upd(l.id, { status: "active", removed_by_admin: false })}>Restore</Button>
                : <Button size="sm" variant="destructive" onClick={() => upd(l.id, { status: "removed", removed_by_admin: true })}>Remove</Button>}
            </td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

function Reports() {
  const fn = useServerFn(adminListReports);
  const q = useQuery({ queryKey: ["admin-reports"], queryFn: () => fn() });
  const setStatus = async (id: string, status: "under_review" | "resolved" | "rejected") => {
    const { error } = await supabase.from("reports").update({ status }).eq("id", id);
    if (error) toast.error(error.message); else q.refetch();
  };
  const removeListing = async (lid: string) => {
    const { error } = await supabase.from("listings").update({ status: "removed", removed_by_admin: true }).eq("id", lid);
    if (error) toast.error(error.message); else { toast.success("Listing removed"); q.refetch(); }
  };
  if (!q.data) return <p className="text-muted-foreground">Loading…</p>;
  if (!q.data.length) return <p className="text-muted-foreground">No reports.</p>;
  return (
    <div className="space-y-3">{q.data.map((r: any) => (
      <div key={r.id} className="rounded-lg border bg-card p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div><Badge variant="secondary" className="capitalize">{r.status.replace("_", " ")}</Badge> <span className="font-semibold">{REPORT_REASONS.find((x) => x.value === r.reason)?.label}</span></div>
          <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("en-IN")}</span>
        </div>
        {r.listings && <p className="mt-1 text-sm">Listing: <Link to="/listing/$id" params={{ id: r.listings.id }} className="underline">{r.listings.title}</Link> ({r.listings.status})</p>}
        <p className="text-sm text-muted-foreground">By {r.reporter?.full_name || r.reporter?.email || "user"}</p>
        {r.details && <p className="mt-2 text-sm">{r.details}</p>}
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "under_review")}>Under review</Button>
          <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "resolved")}>Resolve</Button>
          <Button size="sm" variant="outline" onClick={() => setStatus(r.id, "rejected")}>Reject</Button>
          {r.listings && r.listings.status !== "removed" && <Button size="sm" variant="destructive" onClick={() => removeListing(r.listings.id)}>Remove listing</Button>}
        </div>
      </div>
    ))}</div>
  );
}
