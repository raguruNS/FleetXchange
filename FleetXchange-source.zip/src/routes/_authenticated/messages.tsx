import { createFileRoute, Link, Outlet, useMatch } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/messages")({
  head: () => ({ meta: [{ title: "Messages — FleetXchange" }, { name: "description", content: "Your conversations with buyers and sellers." }] }),
  component: Messages,
});

export function useConversations() {
  return useQuery({
    queryKey: ["conversations"],
    refetchInterval: 10000,
    queryFn: async () => (await supabase.rpc("my_conversations")).data ?? [],
  });
}

function Messages() {
  const q = useConversations();
  const child = useMatch({ from: "/_authenticated/messages/$id", shouldThrow: false });
  return (
    <div className="mx-auto grid max-w-6xl gap-4 px-4 py-8 md:grid-cols-[320px_1fr]">
      <aside className={`rounded-lg border bg-card ${child ? "hidden md:block" : ""}`}>
        <h1 className="border-b p-4 text-lg font-bold">Messages</h1>
        {q.isLoading ? <p className="p-4 text-muted-foreground">Loading…</p> : !q.data?.length ? (
          <p className="p-4 text-sm text-muted-foreground">No conversations yet. Open a listing and tap "Chat with seller".</p>
        ) : q.data.map((c) => (
          <Link key={c.id} to="/messages/$id" params={{ id: c.id }} className="block border-b p-3 hover:bg-muted" activeProps={{ className: "bg-muted" }}>
            <div className="flex justify-between gap-2"><span className="truncate font-semibold">{c.other_name || "User"}</span>{c.unread > 0 && <span className="rounded-full bg-primary px-2 text-xs text-primary-foreground">{c.unread}</span>}</div>
            <div className="truncate text-xs text-muted-foreground">{c.listing_title}</div>
            <div className="truncate text-sm">{c.last_message}</div>
          </Link>
        ))}
      </aside>
      <section className={child ? "" : "hidden md:block"}>
        {child ? <Outlet /> : <div className="grid h-full min-h-60 place-items-center rounded-lg border border-dashed text-muted-foreground">Select a conversation</div>}
      </section>
    </div>
  );
}
