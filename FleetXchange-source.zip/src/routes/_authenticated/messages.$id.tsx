import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/messages/$id")({
  head: () => ({ meta: [{ title: "Conversation — FleetXchange" }, { name: "description", content: "Chat with a buyer or seller." }] }),
  component: Chat,
});

function Chat() {
  const { id } = Route.useParams();
  const { user } = useSession();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const bottom = useRef<HTMLDivElement>(null);
  const conv = useQuery({
    queryKey: ["conversation", id],
    queryFn: async () => (await supabase.from("conversations").select("*, listings(id, title)").eq("id", id).maybeSingle()).data,
  });
  const msgs = useQuery({
    queryKey: ["messages", id],
    refetchInterval: 4000,
    queryFn: async () => (await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at")).data ?? [],
  });
  useEffect(() => {
    const ch = supabase.channel("msgs-" + id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${id}` }, () => msgs.refetch())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id]);
  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "end" });
    if (!user || !msgs.data) return;
    const unread = msgs.data.some((m) => m.sender_id !== user.id && !m.read_at);
    if (unread) supabase.from("messages").update({ read_at: new Date().toISOString() }).eq("conversation_id", id).neq("sender_id", user.id).is("read_at", null).then(() => qc.invalidateQueries({ queryKey: ["conversations"] }));
  }, [msgs.data, user]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const body = text.trim();
    if (!body) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({ conversation_id: id, body: body.slice(0, 2000) });
    setSending(false);
    if (error) { toast.error(error.message.includes("row-level") ? "Verify your mobile number to send messages." : error.message); return; }
    setText(""); msgs.refetch(); qc.invalidateQueries({ queryKey: ["conversations"] });
  }

  const l = conv.data?.listings as { id: string; title: string } | null | undefined;
  return (
    <div className="flex h-[70vh] flex-col rounded-lg border bg-card">
      <div className="flex items-center gap-2 border-b p-3">
        <Link to="/messages" className="md:hidden" aria-label="Back"><ArrowLeft className="h-4 w-4" /></Link>
        {l ? <Link to="/listing/$id" params={{ id: l.id }} className="truncate font-semibold hover:underline">{l.title}</Link> : <span className="font-semibold">Conversation</span>}
      </div>
      <div className="flex-1 space-y-2 overflow-y-auto p-4">
        {msgs.data?.map((m) => (
          <div key={m.id} className={`flex ${m.sender_id === user?.id ? "justify-end" : ""}`}>
            <div className={`max-w-[75%] rounded-lg px-3 py-2 text-sm ${m.sender_id === user?.id ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              <p className="whitespace-pre-wrap break-words">{m.body}</p>
              <p className="mt-1 text-[10px] opacity-70">{new Date(m.created_at).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" })}{m.sender_id === user?.id && m.read_at ? " · Seen" : ""}</p>
            </div>
          </div>
        ))}
        <div ref={bottom} />
      </div>
      <form onSubmit={send} className="flex gap-2 border-t p-3">
        <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" maxLength={2000} />
        <Button type="submit" disabled={sending || !text.trim()} aria-label="Send"><Send className="h-4 w-4" /></Button>
      </form>
    </div>
  );
}
