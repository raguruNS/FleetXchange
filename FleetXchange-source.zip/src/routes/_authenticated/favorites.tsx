import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/auth";
import { ListingGrid } from "@/components/site/ListingGrid";
import { CARD_COLS, type ListingRow } from "@/components/site/ListingCard";

export const Route = createFileRoute("/_authenticated/favorites")({
  head: () => ({ meta: [{ title: "Favorites — FleetXchange" }, { name: "description", content: "Your saved listings on FleetXchange." }] }),
  component: Favorites,
});

function Favorites() {
  const { user } = useSession();
  const q = useQuery({
    queryKey: ["favorites", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("favorites").select(`listings(${CARD_COLS})`).eq("user_id", user!.id).order("created_at", { ascending: false });
      return (data ?? []).map((r: any) => r.listings).filter(Boolean) as ListingRow[];
    },
  });
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold">Favorites</h1>
      {q.isLoading ? <p className="text-muted-foreground">Loading…</p> : <ListingGrid rows={q.data ?? []} empty="No saved listings yet. Tap the heart on any listing to save it." />}
    </div>
  );
}
