import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { BadgeCheck, MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { ListingGrid } from "@/components/site/ListingGrid";
import { CARD_COLS, type ListingRow } from "@/components/site/ListingCard";

export const Route = createFileRoute("/seller/$id")({
  head: () => ({
    meta: [
      { title: "Seller profile — FleetXchange" },
      { name: "description", content: "See this seller's verification status and active listings." },
      { property: "og:title", content: "Seller on FleetXchange" },
      { property: "og:description", content: "Verified seller of buses, trucks and spare parts." },
    ],
  }),
  component: SellerPage,
});

function SellerPage() {
  const { id } = Route.useParams();
  const { data: s } = useQuery({ queryKey: ["seller", id], queryFn: async () => (await supabase.rpc("get_seller", { _id: id })).data?.[0] ?? null });
  const { data: rows } = useQuery({ queryKey: ["seller-listings", id], queryFn: async () => (await supabase.from("listings").select(CARD_COLS).eq("seller_id", id).eq("status", "active").order("created_at", { ascending: false })).data ?? [] });
  if (s === null) return <div className="mx-auto max-w-7xl p-8">Seller not found.</div>;
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="rounded-lg border bg-card p-6">
        <h1 className="text-3xl font-bold">{s?.full_name || "Seller"}</h1>
        {s?.location && <div className="mt-1 flex items-center gap-1 text-muted-foreground"><MapPin className="h-4 w-4" />{s.location}</div>}
        <div className="mt-2 flex gap-3 text-sm">
          {s?.phone_verified && <span className="flex items-center gap-1 text-success"><BadgeCheck className="h-4 w-4" />Mobile verified</span>}
          {s?.email_verified && <span className="flex items-center gap-1 text-success"><BadgeCheck className="h-4 w-4" />Email verified</span>}
        </div>
        {s?.bio && <p className="mt-3 text-muted-foreground">{s.bio}</p>}
      </div>
      <h2 className="mb-4 mt-8 text-xl font-bold">Active listings</h2>
      <ListingGrid rows={(rows ?? []) as ListingRow[]} />
    </div>
  );
}
