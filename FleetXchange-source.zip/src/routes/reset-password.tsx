import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { isStrongPassword } from "@/lib/constants";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password — FleetXchange" },
      { name: "description", content: "Choose a new password for your FleetXchange account." },
      { property: "og:title", content: "Reset password — FleetXchange" },
      { property: "og:description", content: "Choose a new password." },
    ],
  }),
  component: Reset,
});

function Reset() {
  const [pw, setPw] = useState("");
  const navigate = useNavigate();
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isStrongPassword(pw)) { toast.error("Use 8+ characters with upper, lower, number and symbol."); return; }
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) { toast.error("Reset link is invalid or expired."); return; }
    toast.success("Password updated."); navigate({ to: "/" });
  };
  return (
    <form onSubmit={submit} className="mx-auto mt-12 max-w-md space-y-4 rounded-lg border bg-card p-6">
      <h1 className="text-xl font-bold">Set a new password</h1>
      <div><Label>New password</Label><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} /></div>
      <Button className="w-full">Update password</Button>
    </form>
  );
}
