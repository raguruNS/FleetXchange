import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { checkRegistration, loginWithPhone } from "@/lib/account.functions";
import { INDIAN_STATES, isStrongPassword, normalizeIndianMobile, PASSWORD_RULES } from "@/lib/constants";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Log in or sign up — FleetXchange" },
      { name: "description", content: "Create a FleetXchange account to sell vehicles and parts, save favorites and chat with sellers." },
      { property: "og:title", content: "Log in — FleetXchange" },
      { property: "og:description", content: "Join India's commercial vehicle marketplace." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <Tabs defaultValue="login">
        <TabsList className="grid w-full grid-cols-2"><TabsTrigger value="login">Log in</TabsTrigger><TabsTrigger value="signup">Sign up</TabsTrigger></TabsList>
        <TabsContent value="login"><Login /></TabsContent>
        <TabsContent value="signup"><Signup /></TabsContent>
      </Tabs>
    </div>
  );
}

function Login() {
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  const [forgot, setForgot] = useState(false);
  const navigate = useNavigate();
  const phoneLogin = useServerFn(loginWithPhone);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    try {
      if (forgot) {
        if (!id.includes("@")) throw new Error("Enter your email to reset your password.");
        await supabase.auth.resetPasswordForEmail(id.trim(), { redirectTo: `${window.location.origin}/reset-password` });
        toast.success("If that email is registered, a reset link is on its way.");
        setForgot(false); return;
      }
      if (id.includes("@")) {
        const { error } = await supabase.auth.signInWithPassword({ email: id.trim(), password: pw });
        if (error) throw new Error(error.message.toLowerCase().includes("confirm") ? "Please verify your email before logging in." : "Invalid email or password.");
      } else {
        const t = await phoneLogin({ data: { phone: id, password: pw } });
        await supabase.auth.setSession(t);
      }
      navigate({ to: "/" });
    } catch (err) { toast.error((err as Error).message); } finally { setBusy(false); }
  };
  return (
    <form onSubmit={submit} className="mt-4 space-y-4 rounded-lg border bg-card p-6">
      <div><Label>Email or mobile number</Label><Input value={id} onChange={(e) => setId(e.target.value)} required /></div>
      {!forgot && <div><Label>Password</Label><Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} required /></div>}
      <Button className="w-full" disabled={busy}>{forgot ? "Send reset link" : "Log in"}</Button>
      <button type="button" className="w-full text-sm text-primary" onClick={() => setForgot(!forgot)}>{forgot ? "Back to login" : "Forgot password?"}</button>
    </form>
  );
}

function Signup() {
  const [f, setF] = useState({ full_name: "", email: "", phone: "", city: "", state: "", password: "", confirm: "" });
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const check = useServerFn(checkRegistration);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (f.full_name.trim().length < 2) { toast.error("Enter your full name."); return; }
    const phone = normalizeIndianMobile(f.phone);
    if (!phone) { toast.error("Enter a valid 10-digit Indian mobile number."); return; }
    if (!isStrongPassword(f.password)) { toast.error("Password doesn't meet the requirements."); return; }
    if (f.password !== f.confirm) { toast.error("Passwords don't match."); return; }
    setBusy(true);
    try {
      const r = await check({ data: { phone } });
      if (!r.phoneOk) throw new Error(r.reason ?? "Mobile number not allowed.");
      const { error } = await supabase.auth.signUp({
        email: f.email.trim(), password: f.password,
        options: { emailRedirectTo: window.location.origin, data: { full_name: f.full_name.trim(), phone, location: [f.city.trim(), f.state].filter(Boolean).join(", ") } },
      });
      if (error) throw new Error(error.message.includes("registered") ? "This email is already registered." : error.message);
      setDone(true);
    } catch (err) { toast.error((err as Error).message); } finally { setBusy(false); }
  };
  if (done) return (
    <div className="mt-4 rounded-lg border bg-card p-6 text-center">
      <h2 className="text-xl font-bold">Check your email</h2>
      <p className="mt-2 text-muted-foreground">We sent a verification link to <b>{f.email}</b>. Click it to activate your account, then log in and verify your mobile number.</p>
    </div>
  );
  return (
    <form onSubmit={submit} className="mt-4 space-y-3 rounded-lg border bg-card p-6">
      <div><Label>Full name</Label><Input value={f.full_name} onChange={set("full_name")} required maxLength={80} /></div>
      <div><Label>Email</Label><Input type="email" value={f.email} onChange={set("email")} required /></div>
      <div><Label>Mobile number</Label><Input value={f.phone} onChange={set("phone")} placeholder="98765 43210" required /></div>
      <div className="grid grid-cols-2 gap-2">
        <div><Label>City</Label><Input value={f.city} onChange={set("city")} /></div>
        <div><Label>State</Label><select className="h-9 w-full rounded-md border bg-card px-2 text-sm" value={f.state} onChange={set("state")}><option value="">Select</option>{INDIAN_STATES.map((s) => <option key={s}>{s}</option>)}</select></div>
      </div>
      <div><Label>Password</Label><Input type="password" value={f.password} onChange={set("password")} required /></div>
      <ul className="grid grid-cols-2 gap-1 text-xs">
        {PASSWORD_RULES.map((r) => { const ok = r.test(f.password); return <li key={r.label} className={`flex items-center gap-1 ${ok ? "text-success" : "text-muted-foreground"}`}>{ok ? <Check className="h-3 w-3" /> : <X className="h-3 w-3" />}{r.label}</li>; })}
      </ul>
      <div><Label>Confirm password</Label><Input type="password" value={f.confirm} onChange={set("confirm")} required /></div>
      <Button className="w-full" disabled={busy}>Create account</Button>
    </form>
  );
}
