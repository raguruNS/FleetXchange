import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { ListingGrid } from "@/components/site/ListingGrid";
import { CARD_COLS, type ListingRow } from "@/components/site/ListingCard";
import { FUEL_TYPES, INDIAN_STATES, PART_CATEGORIES, VEHICLE_BRANDS } from "@/lib/constants";

const schema = z.object({
  q: z.string().optional(),
  kind: z.enum(["vehicle", "part"]).optional(),
  vt: z.enum(["bus", "truck"]).optional(),
  tier: z.enum(["standard", "premium"]).optional(),
  cond: z.enum(["new", "used"]).optional(),
  brand: z.string().optional(),
  cat: z.string().optional(),
  fuel: z.string().optional(),
  state: z.string().optional(),
  city: z.string().optional(),
  min: z.coerce.number().optional(),
  max: z.coerce.number().optional(),
  ymin: z.coerce.number().optional(),
  sort: z.enum(["new", "price_asc", "price_desc", "km"]).optional(),
});
type S = z.infer<typeof schema>;

export const Route = createFileRoute("/browse")({
  validateSearch: (s) => schema.parse(s),
  head: () => ({
    meta: [
      { title: "Browse Buses, Trucks & Spare Parts — FleetXchange" },
      { name: "description", content: "Filter used buses, trucks and spare parts by brand, price, year, fuel and location." },
      { property: "og:title", content: "Browse listings — FleetXchange" },
      { property: "og:description", content: "Find used buses, trucks and spare parts across India." },
    ],
  }),
  component: Browse,
});

const sel = "h-9 w-full rounded-md border border-input bg-card px-2 text-sm";

function Browse() {
  const s = Route.useSearch();
  const navigate = useNavigate({ from: "/browse" });
  const set = (patch: Partial<S>) => navigate({ search: (p: S) => ({ ...p, ...patch }) });
  const [q, setQ] = useState(s.q ?? "");

  const res = useQuery({
    queryKey: ["browse", s],
    queryFn: async () => {
      let x = supabase.from("listings").select(CARD_COLS).eq("status", "active").limit(120);
      if (s.kind) x = x.eq("kind", s.kind);
      if (s.vt) x = x.eq("vehicle_type", s.vt);
      if (s.tier) x = x.eq("tier", s.tier);
      if (s.cond) x = x.eq("part_condition", s.cond);
      if (s.brand) x = x.or(`brand.eq.${s.brand},compat_brand.eq.${s.brand}`);
      if (s.cat) x = x.eq("part_category", s.cat);
      if (s.fuel) x = x.eq("fuel", s.fuel);
      if (s.state) x = x.eq("state", s.state);
      if (s.city) x = x.ilike("city", `%${s.city.replace(/[%,()]/g, "")}%`);
      if (s.min) x = x.gte("price", s.min);
      if (s.max) x = x.lte("price", s.max);
      if (s.ymin) x = x.gte("mfg_year", s.ymin);
      const term = s.q?.trim().replace(/[%,()]/g, "");
      if (term) x = x.or(`title.ilike.%${term}%,brand.ilike.%${term}%,model.ilike.%${term}%,part_number.ilike.%${term}%,compat_model.ilike.%${term}%`);
      if (s.sort === "price_asc") x = x.order("price", { ascending: true });
      else if (s.sort === "price_desc") x = x.order("price", { ascending: false });
      else if (s.sort === "km") x = x.order("km", { ascending: true, nullsFirst: false });
      else x = x.order("tier", { ascending: true }).order("created_at", { ascending: false });
      const { data, error } = await x;
      if (error) throw error;
      return data as ListingRow[];
    },
  });

  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 lg:grid-cols-[260px_1fr]">
      <aside className="space-y-4 rounded-lg border bg-card p-4 lg:sticky lg:top-20 lg:self-start">
        <form onSubmit={(e) => { e.preventDefault(); set({ q: q || undefined }); }}>
          <Label>Search</Label>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Model, part number…" />
        </form>
        <F label="Category">
          <select className={sel} value={s.kind === "part" ? "part" : s.vt ?? ""} onChange={(e) => {
            const v = e.target.value;
            set(v === "part" ? { kind: "part", vt: undefined, tier: undefined } : v ? { kind: "vehicle", vt: v as "bus" | "truck", cond: undefined, cat: undefined } : { kind: undefined, vt: undefined });
          }}>
            <option value="">All</option><option value="bus">Buses</option><option value="truck">Trucks</option><option value="part">Spare parts</option>
          </select>
        </F>
        {s.kind === "vehicle" && (
          <>
            <F label="Tier"><select className={sel} value={s.tier ?? ""} onChange={(e) => set({ tier: (e.target.value || undefined) as S["tier"] })}><option value="">Any</option><option value="standard">Standard</option><option value="premium">Premium</option></select></F>
            <F label="Fuel"><select className={sel} value={s.fuel ?? ""} onChange={(e) => set({ fuel: e.target.value || undefined })}><option value="">Any</option>{FUEL_TYPES.map((f) => <option key={f}>{f}</option>)}</select></F>
            <F label="Min. year"><Input type="number" defaultValue={s.ymin} onBlur={(e) => set({ ymin: e.target.value ? +e.target.value : undefined })} /></F>
          </>
        )}
        {s.kind === "part" && (
          <>
            <F label="Condition"><select className={sel} value={s.cond ?? ""} onChange={(e) => set({ cond: (e.target.value || undefined) as S["cond"] })}><option value="">Any</option><option value="new">New</option><option value="used">Used</option></select></F>
            <F label="Part category"><select className={sel} value={s.cat ?? ""} onChange={(e) => set({ cat: e.target.value || undefined })}><option value="">Any</option>{PART_CATEGORIES.map((f) => <option key={f}>{f}</option>)}</select></F>
          </>
        )}
        <F label="Brand"><select className={sel} value={s.brand ?? ""} onChange={(e) => set({ brand: e.target.value || undefined })}><option value="">Any</option>{VEHICLE_BRANDS.map((f) => <option key={f}>{f}</option>)}</select></F>
        <div className="grid grid-cols-2 gap-2">
          <F label="Min ₹"><Input type="number" defaultValue={s.min} onBlur={(e) => set({ min: e.target.value ? +e.target.value : undefined })} /></F>
          <F label="Max ₹"><Input type="number" defaultValue={s.max} onBlur={(e) => set({ max: e.target.value ? +e.target.value : undefined })} /></F>
        </div>
        <F label="State"><select className={sel} value={s.state ?? ""} onChange={(e) => set({ state: e.target.value || undefined })}><option value="">All India</option>{INDIAN_STATES.map((f) => <option key={f}>{f}</option>)}</select></F>
        <F label="City"><Input defaultValue={s.city} onBlur={(e) => set({ city: e.target.value || undefined })} /></F>
        <Button variant="outline" className="w-full" onClick={() => { setQ(""); navigate({ search: {} }); }}>Clear filters</Button>
      </aside>
      <section>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h1 className="text-2xl font-bold">{s.kind === "part" ? "Spare parts" : s.vt === "bus" ? "Buses" : s.vt === "truck" ? "Trucks" : "All listings"} <span className="text-base font-normal text-muted-foreground">({res.data?.length ?? 0})</span></h1>
          <select className={sel + " w-auto"} value={s.sort ?? "new"} onChange={(e) => set({ sort: e.target.value as S["sort"] })}>
            <option value="new">Newest first</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option><option value="km">Lowest KM</option>
          </select>
        </div>
        {res.isLoading ? <p className="text-muted-foreground">Loading…</p> : <ListingGrid rows={res.data ?? []} />}
      </section>
    </div>
  );
}

function F({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1"><Label className="text-xs text-muted-foreground">{label}</Label>{children}</div>;
}
