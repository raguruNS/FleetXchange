import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, Flag, Heart, MapPin, MessageSquare, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/auth";
import { imagesOf, useSignedUrls } from "@/lib/images";
import { formatINR, formatKM, maskPhone, REPORT_REASONS, vehicleLabel } from "@/lib/constants";

export const Route = createFileRoute("/listing/$id")({
  head: () => ({
    meta: [
      { title: "Listing details — FleetXchange" },
      { name: "description", content: "View vehicle or spare part details, photos and contact the verified seller." },
      { property: "og:title", content: "Listing on FleetXchange" },
      { property: "og:description", content: "Buses, trucks and spare parts from verified sellers." },
    ],
  }),
  component: ListingPage,
});

function ListingPage() {
  const { id } = Route.useParams();
  const { user, profile } = useProfile();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [idx, setIdx] = useState(0);

  const { data: l, isLoading } = useQuery({
    queryKey: ["listing", id, user?.id],
    queryFn: async () => (await supabase.from("listings").select("*").eq("id", id).maybeSingle()).data,
  });
  const { data: seller } = useQuery({
    queryKey: ["seller", l?.seller_id, user?.id],
    enabled: !!l,
    queryFn: async () => (await supabase.rpc("get_seller", { _id: l!.seller_id })).data?.[0] ?? null,
  });
  const { data: fav } = useQuery({
    queryKey: ["fav", id, user?.id],
    enabled: !!user,
    queryFn: async () => !!(await supabase.from("favorites").select("id").eq("listing_id", id).maybeSingle()).data,
  });
  const imgs = imagesOf(l?.images);
  const urls = useSignedUrls(imgs.map((i) => i.path));

  if (isLoading) return <div className="mx-auto max-w-7xl p-8 text-muted-foreground">Loading…</div>;
  if (!l) return <div className="mx-auto max-w-7xl p-8"><h1 className="text-2xl font-bold">Listing not available</h1><p className="text-muted-foreground">It may have been removed or sold.</p></div>;

  const isOwner = user?.id === l.seller_id;
  const specs = (l.specs ?? {}) as Record<string, string>;
  const rows: [string, unknown][] = l.kind === "vehicle"
    ? [["Brand", l.brand], ["Model", l.model], ["Manufacturing year", l.mfg_year], ["Registration year", l.reg_year], ["KM driven", formatKM(l.km)], ["Fuel", l.fuel], ["Transmission", l.transmission], ["Owners", l.owners], ...Object.entries(specs)]
    : [["Category", l.part_category], ["Condition", l.part_condition === "new" ? "New" : "Used"], ["Brand", l.brand], ["Part number", l.part_number], ["Quantity", l.quantity], ["Fits vehicle", l.compat_vehicle_type], ["Fits brand", l.compat_brand], ["Fits model", l.compat_model], ["Fits year", l.compat_year], ...Object.entries(specs)];

  const toggleFav = async () => {
    if (!user) return navigate({ to: "/auth" });
    if (fav) await supabase.from("favorites").delete().eq("listing_id", id);
    else await supabase.from("favorites").insert({ listing_id: id });
    qc.invalidateQueries({ queryKey: ["fav", id] });
  };

  const chat = async () => {
    if (!user) return navigate({ to: "/auth" });
    if (!profile?.phone_verified) { toast.error("Verify your mobile number to chat with sellers."); return navigate({ to: "/account" }); }
    const { data: existing } = await supabase.from("conversations").select("id").eq("listing_id", id).eq("buyer_id", user.id).maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const { data, error } = await supabase.from("conversations").insert({ listing_id: id, seller_id: l.seller_id }).select("id").single();
      if (error) { toast.error("Could not start chat."); return; }
      convId = data.id;
    }
    navigate({ to: "/messages/$id", params: { id: convId } });
  };

  return (
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-8 lg:grid-cols-[1fr_360px]">
      <div>
        <div className="aspect-[16/10] overflow-hidden rounded-lg bg-muted">
          {imgs[idx] && urls[imgs[idx].path] ? <img src={urls[imgs[idx].path]} alt={imgs[idx].label ?? l.title} className="h-full w-full object-contain" /> : <div className="grid h-full place-items-center text-muted-foreground">No photos</div>}
        </div>
        {imgs.length > 1 && (
          <div className="mt-2 flex gap-2 overflow-x-auto">
            {imgs.map((im, i) => (
              <button key={im.path} onClick={() => setIdx(i)} className={`h-16 w-20 shrink-0 overflow-hidden rounded border-2 ${i === idx ? "border-primary" : "border-transparent"}`}>
                {urls[im.path] && <img src={urls[im.path]} alt={im.label} className="h-full w-full object-cover" />}
              </button>
            ))}
          </div>
        )}
        <h2 className="mt-8 text-xl font-bold">Details</h2>
        <dl className="mt-3 grid grid-cols-2 gap-px overflow-hidden rounded-lg border bg-border sm:grid-cols-3">
          {rows.filter(([, v]) => v !== null && v !== undefined && v !== "").map(([k, v]) => (
            <div key={k} className="bg-card p-3"><dt className="text-xs text-muted-foreground">{k}</dt><dd className="font-medium">{String(v)}</dd></div>
          ))}
        </dl>
        {l.description && <><h2 className="mt-8 text-xl font-bold">Description</h2><p className="mt-2 whitespace-pre-line text-muted-foreground">{l.description}</p></>}
      </div>
      <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start">
        <div className="rounded-lg border bg-card p-5">
          <div className="flex flex-wrap gap-2">
            <Badge className={l.tier === "premium" ? "bg-premium text-premium-foreground" : ""}>{l.kind === "part" ? "Spare part" : vehicleLabel(l.vehicle_type, l.tier)}</Badge>
            {l.status !== "active" && <Badge variant="destructive">{l.status.toUpperCase()}</Badge>}
          </div>
          <h1 className="mt-3 text-2xl font-bold">{l.title}</h1>
          <div className="mt-2 font-display text-3xl font-extrabold text-primary">{formatINR(l.price)}</div>
          <div className="mt-2 flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="h-4 w-4" />{[l.area, l.city, l.state].filter(Boolean).join(", ")}</div>
          <div className="mt-4 grid gap-2">
            {isOwner ? (
              <Button asChild><Link to="/sell" search={{ edit: l.id }}>Edit listing</Link></Button>
            ) : (
              <>
                <Button onClick={chat} disabled={l.status !== "active"}><MessageSquare className="h-4 w-4" />Chat with seller</Button>
                {seller?.phone && <Button asChild variant="outline"><a href={`tel:${seller.phone}`}><Phone className="h-4 w-4" />{maskPhone(seller.phone)}</a></Button>}
                {!user && <p className="text-center text-xs text-muted-foreground">Log in to see the seller's phone number.</p>}
              </>
            )}
            <Button variant="ghost" onClick={toggleFav}><Heart className={`h-4 w-4 ${fav ? "fill-primary text-primary" : ""}`} />{fav ? "Saved" : "Save"}</Button>
          </div>
        </div>
        {seller && (
          <Link to="/seller/$id" params={{ id: seller.id }} className="block rounded-lg border bg-card p-5 hover:border-primary">
            <div className="text-xs text-muted-foreground">Seller</div>
            <div className="font-bold">{seller.full_name || "Seller"}</div>
            <div className="mt-1 flex flex-wrap gap-2 text-xs">
              {seller.phone_verified && <span className="flex items-center gap-1 text-success"><BadgeCheck className="h-3 w-3" />Mobile verified</span>}
              {seller.email_verified && <span className="flex items-center gap-1 text-success"><BadgeCheck className="h-3 w-3" />Email verified</span>}
            </div>
            <div className="mt-1 text-xs text-muted-foreground">Member since {new Date(seller.created_at).toLocaleDateString("en-IN", { month: "short", year: "numeric" })}</div>
          </Link>
        )}
        {!isOwner && <ReportDialog listingId={l.id} />}
      </aside>
    </div>
  );
}

function ReportDialog({ listingId }: { listingId: string }) {
  const { user } = useProfile();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("fraud");
  const [details, setDetails] = useState("");
  const submit = async () => {
    const { error } = await supabase.from("reports").insert({ listing_id: listingId, reason: reason as never, details: details.slice(0, 1000) || null });
    if (error) { toast.error("Could not submit report."); return; }
    toast.success("Thanks — our team will review this listing.");
    setOpen(false);
  };
  return (
    <Dialog open={open} onOpenChange={(o) => { if (o && !user) { navigate({ to: "/auth" }); return; } setOpen(o); }}>
      <DialogTrigger asChild><Button variant="ghost" size="sm" className="w-full text-muted-foreground"><Flag className="h-4 w-4" />Report this listing</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Report listing</DialogTitle></DialogHeader>
        <select className="h-9 rounded-md border bg-card px-2" value={reason} onChange={(e) => setReason(e.target.value)}>
          {REPORT_REASONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <Textarea placeholder="Details (optional)" value={details} onChange={(e) => setDetails(e.target.value)} maxLength={1000} />
        <Button onClick={submit}>Submit report</Button>
      </DialogContent>
    </Dialog>
  );
}
