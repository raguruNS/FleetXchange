export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      conversations: {
        Row: {
          buyer_id: string
          created_at: string
          id: string
          last_message_at: string
          listing_id: string
          seller_id: string
        }
        Insert: {
          buyer_id?: string
          created_at?: string
          id?: string
          last_message_at?: string
          listing_id: string
          seller_id: string
        }
        Update: {
          buyer_id?: string
          created_at?: string
          id?: string
          last_message_at?: string
          listing_id?: string
          seller_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      favorites: {
        Row: {
          created_at: string
          id: string
          listing_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          listing_id: string
          user_id?: string
        }
        Update: {
          created_at?: string
          id?: string
          listing_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      listings: {
        Row: {
          area: string | null
          brand: string | null
          city: string | null
          compat_brand: string | null
          compat_model: string | null
          compat_vehicle_type: string | null
          compat_year: string | null
          created_at: string
          description: string | null
          fuel: string | null
          id: string
          images: Json
          kind: Database["public"]["Enums"]["listing_kind"]
          km: number | null
          mfg_year: number | null
          model: string | null
          owners: number | null
          part_category: string | null
          part_condition: Database["public"]["Enums"]["part_condition"] | null
          part_number: string | null
          price: number
          quantity: number | null
          reg_year: number | null
          removed_by_admin: boolean
          seller_id: string
          sold_at: string | null
          specs: Json
          state: string | null
          status: Database["public"]["Enums"]["listing_status"]
          suspicious: boolean
          tier: Database["public"]["Enums"]["listing_tier"]
          title: string
          transmission: string | null
          updated_at: string
          vehicle_type: Database["public"]["Enums"]["vehicle_type"] | null
        }
        Insert: {
          area?: string | null
          brand?: string | null
          city?: string | null
          compat_brand?: string | null
          compat_model?: string | null
          compat_vehicle_type?: string | null
          compat_year?: string | null
          created_at?: string
          description?: string | null
          fuel?: string | null
          id?: string
          images?: Json
          kind: Database["public"]["Enums"]["listing_kind"]
          km?: number | null
          mfg_year?: number | null
          model?: string | null
          owners?: number | null
          part_category?: string | null
          part_condition?: Database["public"]["Enums"]["part_condition"] | null
          part_number?: string | null
          price: number
          quantity?: number | null
          reg_year?: number | null
          removed_by_admin?: boolean
          seller_id?: string
          sold_at?: string | null
          specs?: Json
          state?: string | null
          status?: Database["public"]["Enums"]["listing_status"]
          suspicious?: boolean
          tier?: Database["public"]["Enums"]["listing_tier"]
          title: string
          transmission?: string | null
          updated_at?: string
          vehicle_type?: Database["public"]["Enums"]["vehicle_type"] | null
        }
        Update: {
          area?: string | null
          brand?: string | null
          city?: string | null
          compat_brand?: string | null
          compat_model?: string | null
          compat_vehicle_type?: string | null
          compat_year?: string | null
          created_at?: string
          description?: string | null
          fuel?: string | null
          id?: string
          images?: Json
          kind?: Database["public"]["Enums"]["listing_kind"]
          km?: number | null
          mfg_year?: number | null
          model?: string | null
          owners?: number | null
          part_category?: string | null
          part_condition?: Database["public"]["Enums"]["part_condition"] | null
          part_number?: string | null
          price?: number
          quantity?: number | null
          reg_year?: number | null
          removed_by_admin?: boolean
          seller_id?: string
          sold_at?: string | null
          specs?: Json
          state?: string | null
          status?: Database["public"]["Enums"]["listing_status"]
          suspicious?: boolean
          tier?: Database["public"]["Enums"]["listing_tier"]
          title?: string
          transmission?: string | null
          updated_at?: string
          vehicle_type?: Database["public"]["Enums"]["vehicle_type"] | null
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          conversation_id: string
          created_at: string
          id: string
          read_at: string | null
          sender_id: string
        }
        Insert: {
          body: string
          conversation_id: string
          created_at?: string
          id?: string
          read_at?: string | null
          sender_id?: string
        }
        Update: {
          body?: string
          conversation_id?: string
          created_at?: string
          id?: string
          read_at?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      phone_otps: {
        Row: {
          attempts: number
          code_hash: string
          expires_at: string
          last_sent_at: string
          phone: string
          sends_in_window: number
          user_id: string
          window_start: string
        }
        Insert: {
          attempts?: number
          code_hash: string
          expires_at: string
          last_sent_at?: string
          phone: string
          sends_in_window?: number
          user_id: string
          window_start?: string
        }
        Update: {
          attempts?: number
          code_hash?: string
          expires_at?: string
          last_sent_at?: string
          phone?: string
          sends_in_window?: number
          user_id?: string
          window_start?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          bio: string | null
          created_at: string
          email: string | null
          email_notifications: boolean
          full_name: string
          id: string
          is_blocked: boolean
          location: string | null
          phone: string | null
          phone_verified: boolean
          show_phone: boolean
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email?: string | null
          email_notifications?: boolean
          full_name?: string
          id: string
          is_blocked?: boolean
          location?: string | null
          phone?: string | null
          phone_verified?: boolean
          show_phone?: boolean
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          bio?: string | null
          created_at?: string
          email?: string | null
          email_notifications?: boolean
          full_name?: string
          id?: string
          is_blocked?: boolean
          location?: string | null
          phone?: string | null
          phone_verified?: boolean
          show_phone?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          details: string | null
          id: string
          listing_id: string
          reason: Database["public"]["Enums"]["report_reason"]
          reporter_id: string
          status: Database["public"]["Enums"]["report_status"]
        }
        Insert: {
          created_at?: string
          details?: string | null
          id?: string
          listing_id: string
          reason: Database["public"]["Enums"]["report_reason"]
          reporter_id?: string
          status?: Database["public"]["Enums"]["report_status"]
        }
        Update: {
          created_at?: string
          details?: string | null
          id?: string
          listing_id?: string
          reason?: Database["public"]["Enums"]["report_reason"]
          reporter_id?: string
          status?: Database["public"]["Enums"]["report_status"]
        }
        Relationships: [
          {
            foreignKeyName: "reports_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "listings"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_transact: { Args: { _user_id: string }; Returns: boolean }
      claim_first_admin: { Args: never; Returns: boolean }
      get_seller: {
        Args: { _id: string }
        Returns: {
          avatar_url: string
          bio: string
          created_at: string
          email_verified: boolean
          full_name: string
          id: string
          location: string
          phone: string
          phone_verified: boolean
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_participant: {
        Args: { _conv: string; _user: string }
        Returns: boolean
      }
      my_conversations: {
        Args: never
        Returns: {
          id: string
          last_message: string
          last_message_at: string
          listing_id: string
          listing_image: string
          listing_title: string
          other_avatar: string
          other_id: string
          other_name: string
          unread: number
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "user"
      listing_kind: "vehicle" | "part"
      listing_status: "draft" | "active" | "sold" | "removed"
      listing_tier: "standard" | "premium"
      part_condition: "new" | "used"
      report_reason:
        | "fake_vehicle"
        | "fake_part"
        | "incorrect_info"
        | "duplicate"
        | "fraud"
        | "suspicious_seller"
        | "wrong_compatibility"
        | "other"
      report_status: "pending" | "under_review" | "resolved" | "rejected"
      vehicle_type: "bus" | "truck"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
      listing_kind: ["vehicle", "part"],
      listing_status: ["draft", "active", "sold", "removed"],
      listing_tier: ["standard", "premium"],
      part_condition: ["new", "used"],
      report_reason: [
        "fake_vehicle",
        "fake_part",
        "incorrect_info",
        "duplicate",
        "fraud",
        "suspicious_seller",
        "wrong_compatibility",
        "other",
      ],
      report_status: ["pending", "under_review", "resolved", "rejected"],
      vehicle_type: ["bus", "truck"],
    },
  },
} as const
