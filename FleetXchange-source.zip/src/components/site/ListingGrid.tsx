import { useSignedUrls } from "@/lib/images";
import { ListingCard, firstPath, type ListingRow } from "./ListingCard";

export function ListingGrid({ rows, empty = "No listings found." }: { rows: ListingRow[]; empty?: string }) {
  const urls = useSignedUrls(rows.map(firstPath));
  if (!rows.length) return <div className="rounded-lg border border-dashed p-10 text-center text-muted-foreground">{empty}</div>;
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {rows.map((l) => <ListingCard key={l.id} l={l} url={urls[firstPath(l) ?? ""]} />)}
    </div>
  );
}
