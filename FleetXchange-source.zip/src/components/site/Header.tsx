import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, MessageSquare, Plus, Shield, Truck, User, LogOut, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useProfile } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";

export function Header() {
  const { user, profile, isAdmin } = useProfile();
  const navigate = useNavigate();
  return (
    <header className="sticky top-0 z-40 border-b bg-secondary text-secondary-foreground">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-extrabold">
          <span className="grid h-9 w-9 place-items-center rounded bg-primary text-primary-foreground"><Truck className="h-5 w-5" /></span>
          Fleet<span className="text-primary">X</span>change
        </Link>
        <nav className="ml-6 hidden gap-5 text-sm md:flex">
          <Link to="/browse" search={{ kind: "vehicle", vt: "bus" }} className="opacity-80 hover:opacity-100">Buses</Link>
          <Link to="/browse" search={{ kind: "vehicle", vt: "truck" }} className="opacity-80 hover:opacity-100">Trucks</Link>
          <Link to="/browse" search={{ kind: "part" }} className="opacity-80 hover:opacity-100">Spare Parts</Link>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <>
              <Button asChild size="sm" variant="ghost" className="hidden sm:inline-flex"><Link to="/messages"><MessageSquare className="h-4 w-4" /></Link></Button>
              <Button asChild size="sm" variant="ghost" className="hidden sm:inline-flex"><Link to="/favorites"><Heart className="h-4 w-4" /></Link></Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="ghost"><User className="h-4 w-4" /><span className="hidden max-w-28 truncate sm:inline">{profile?.full_name || "Account"}</span></Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => navigate({ to: "/account" })}><User className="h-4 w-4" />My account</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate({ to: "/my-listings" })}><List className="h-4 w-4" />My listings</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate({ to: "/messages" })}><MessageSquare className="h-4 w-4" />Messages</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate({ to: "/favorites" })}><Heart className="h-4 w-4" />Favorites</DropdownMenuItem>
                  {isAdmin && <DropdownMenuItem onClick={() => navigate({ to: "/admin" })}><Shield className="h-4 w-4" />Admin panel</DropdownMenuItem>}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={async () => { await supabase.auth.signOut(); navigate({ to: "/" }); }}><LogOut className="h-4 w-4" />Log out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Button asChild size="sm" variant="ghost"><Link to="/auth">Log in</Link></Button>
          )}
          <Button asChild size="sm"><Link to="/sell"><Plus className="h-4 w-4" />Sell</Link></Button>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-16 border-t bg-secondary text-secondary-foreground">
      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 text-sm sm:grid-cols-3">
        <div>
          <div className="font-display text-lg font-extrabold">Fleet<span className="text-primary">X</span>change</div>
          <p className="mt-2 opacity-70">India's marketplace for used buses, trucks and commercial vehicle spare parts.</p>
        </div>
        <div className="flex flex-col gap-1 opacity-80">
          <Link to="/browse" search={{ kind: "vehicle", vt: "bus" }}>Buy a bus</Link>
          <Link to="/browse" search={{ kind: "vehicle", vt: "truck" }}>Buy a truck</Link>
          <Link to="/browse" search={{ kind: "part" }}>Spare parts</Link>
          <Link to="/sell">Sell on FleetXchange</Link>
        </div>
        <p className="opacity-70">Safety tip: inspect the vehicle and documents in person before paying. Never pay advance to unknown sellers.</p>
      </div>
    </footer>
  );
}
