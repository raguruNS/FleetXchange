import { Link } from "@tanstack/react-router";
import { MapPin, ImageOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatINR, formatKM, vehicleLabel } from "@/lib/constants";
import { imagesOf } from "@/lib/images";

export type ListingRow = {
  id: string; kind: string; vehicle_type: string | null; tier: string; part_condition: string | null;
  title: string; price: number; km: number | null; mfg_year: number | null; fuel: string | null;
  city: string | null; state: string | null; images: unknown; status: string; part_category?: string | null;
};

export function ListingCard({ l, url }: { l: ListingRow; url?: string | undefined }) {
  const tag = l.kind === "part" ? `${l.part_condition === "new" ? "New" : "Used"} Part` : vehicleLabel(l.vehicle_type, l.tier);
  return (
    <Link to="/listing/$id" params={{ id: l.id }} className="group overflow-hidden rounded-lg border bg-card shadow-[var(--shadow-card)] transition hover:-translate-y-0.5">
      <div className="relative aspect-[4/3] bg-muted">
        {url ? <img src={url} alt={l.title} loading="lazy" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-muted-foreground"><ImageOff /></div>}
        <Badge className={`absolute left-2 top-2 ${l.tier === "premium" ? "bg-premium text-premium-foreground" : ""}`}>{tag}</Badge>
        {l.status === "sold" && <Badge variant="destructive" className="absolute right-2 top-2">SOLD</Badge>}
      </div>
      <div className="p-3">
        <div className="font-display text-lg font-bold text-primary">{formatINR(l.price)}</div>
        <div className="line-clamp-1 font-medium">{l.title}</div>
        <div className="mt-1 text-xs text-muted-foreground">
          {l.kind === "vehicle" ? [l.mfg_year, formatKM(l.km), l.fuel].filter(Boolean).join(" · ") : l.part_category}
        </div>
        {(l.city || l.state) && <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground"><MapPin className="h-3 w-3" />{[l.city, l.state].filter(Boolean).join(", ")}</div>}
      </div>
    </Link>
  );
}

export const firstPath = (l: { images: unknown }) => imagesOf(l.images)[0]?.path;
export const CARD_COLS = "id, kind, vehicle_type, tier, part_condition, title, price, km, mfg_year, fuel, city, state, images, status, part_category";
