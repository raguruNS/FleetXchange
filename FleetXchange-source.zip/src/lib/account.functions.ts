import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { createHmac, randomInt, timingSafeEqual } from "crypto";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { normalizeIndianMobile } from "./constants";

const OTP_TTL_MS = 5 * 60 * 1000;
const RESEND_COOLDOWN_MS = 60 * 1000;
const MAX_ATTEMPTS = 5;
const MAX_SENDS_PER_HOUR = 5;

function hashOtp(userId: string, phone: string, code: string) {
  const key = process.env["SUPABASE_SERVICE_ROLE_KEY"] ?? process.env["SUPABASE_URL"] ?? "fx";
  return createHmac("sha256", key).update(`${userId}:${phone}:${code}`).digest("hex");
}

async function sendSms(to: string, body: string) {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const twilioKey = process.env["TWILIO_API_KEY"];
  const from = process.env["TWILIO_FROM_NUMBER"];
  if (!lovableKey || !twilioKey || !from) {
    throw new Error("SMS service isn't set up yet. Please try again later.");
  }
  const res = await fetch("https://connector-gateway.lovable.dev/twilio/Messages.json", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": twilioKey,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({ To: to, From: from, Body: body }),
  });
  if (!res.ok) {
    console.error("SMS send failed", res.status);
    throw new Error("We couldn't send the SMS. Please check your number and try again.");
  }
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const sendPhoneOtp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    const { data: profile } = await db.from("profiles").select("phone, phone_verified").eq("id", context.userId).maybeSingle();
    if (!profile?.phone) throw new Error("Add a mobile number to your profile first.");
    if (profile.phone_verified) return { ok: true, alreadyVerified: true, cooldown: 0 };

    const now = Date.now();
    const { data: existing } = await db.from("phone_otps").select("*").eq("user_id", context.userId).maybeSingle();
    let windowStart = now;
    let sends = 1;
    if (existing) {
      const since = now - new Date(existing.last_sent_at).getTime();
      if (since < RESEND_COOLDOWN_MS) {
        return { ok: false, cooldown: Math.ceil((RESEND_COOLDOWN_MS - since) / 1000), alreadyVerified: false };
      }
      const ws = new Date(existing.window_start).getTime();
      if (now - ws < 60 * 60 * 1000) {
        if (existing.sends_in_window >= MAX_SENDS_PER_HOUR) throw new Error("Too many OTP requests. Try again in an hour.");
        windowStart = ws;
        sends = existing.sends_in_window + 1;
      }
    }
    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    // New OTP replaces (invalidates) any previous one.
    const { error } = await db.from("phone_otps").upsert({
      user_id: context.userId,
      phone: profile.phone,
      code_hash: hashOtp(context.userId, profile.phone, code),
      expires_at: new Date(now + OTP_TTL_MS).toISOString(),
      attempts: 0,
      last_sent_at: new Date(now).toISOString(),
      window_start: new Date(windowStart).toISOString(),
      sends_in_window: sends,
    });
    if (error) throw new Error("Could not create OTP.");
    await sendSms(profile.phone, `${code} is your FleetXchange verification code. It expires in 5 minutes. Do not share it.`);
    return { ok: true, cooldown: RESEND_COOLDOWN_MS / 1000, alreadyVerified: false };
  });

export const verifyPhoneOtp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ code: z.string().regex(/^\d{6}$/) }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await admin();
    const { data: otp } = await db.from("phone_otps").select("*").eq("user_id", context.userId).maybeSingle();
    if (!otp) throw new Error("No active OTP. Please request a new one.");
    if (new Date(otp.expires_at).getTime() < Date.now()) throw new Error("OTP expired. Please request a new one.");
    if (otp.attempts >= MAX_ATTEMPTS) throw new Error("Too many wrong attempts. Please request a new OTP.");
    const expected = Buffer.from(otp.code_hash, "hex");
    const got = Buffer.from(hashOtp(context.userId, otp.phone, data.code), "hex");
    if (expected.length !== got.length || !timingSafeEqual(expected, got)) {
      await db.from("phone_otps").update({ attempts: otp.attempts + 1 }).eq("user_id", context.userId);
      const left = MAX_ATTEMPTS - otp.attempts - 1;
      throw new Error(left > 0 ? `Incorrect OTP. ${left} attempt(s) left.` : "Too many wrong attempts. Please request a new OTP.");
    }
    const { data: profile } = await db.from("profiles").select("phone").eq("id", context.userId).maybeSingle();
    if (profile?.phone !== otp.phone) throw new Error("Your number changed. Please request a new OTP.");
    await db.from("profiles").update({ phone_verified: true }).eq("id", context.userId);
    await db.from("phone_otps").delete().eq("user_id", context.userId);
    return { ok: true };
  });

export const changePhone = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ phone: z.string().min(10).max(16) }).parse(d))
  .handler(async ({ data, context }) => {
    const phone = normalizeIndianMobile(data.phone);
    if (!phone) throw new Error("Enter a valid Indian mobile number.");
    const db = await admin();
    const { data: taken } = await db.from("profiles").select("id").eq("phone", phone).neq("id", context.userId).maybeSingle();
    if (taken) throw new Error("This mobile number is already registered.");
    const { data: cur } = await db.from("profiles").select("phone").eq("id", context.userId).maybeSingle();
    if (cur?.phone === phone) return { ok: true };
    await db.from("profiles").update({ phone, phone_verified: false }).eq("id", context.userId);
    await db.from("phone_otps").delete().eq("user_id", context.userId);
    return { ok: true };
  });

export const checkRegistration = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ phone: z.string().max(16) }).parse(d))
  .handler(async ({ data }) => {
    const phone = normalizeIndianMobile(data.phone);
    if (!phone) return { phoneOk: false, reason: "Enter a valid Indian mobile number." };
    const db = await admin();
    const { data: taken } = await db.from("profiles").select("id").eq("phone", phone).maybeSingle();
    return taken ? { phoneOk: false, reason: "This mobile number is already registered." } : { phoneOk: true, reason: null };
  });

export const loginWithPhone = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ phone: z.string().max(16), password: z.string().min(1).max(200) }).parse(d))
  .handler(async ({ data }) => {
    const generic = "Invalid mobile number or password.";
    const phone = normalizeIndianMobile(data.phone);
    if (!phone) throw new Error(generic);
    const db = await admin();
    const { data: p } = await db.from("profiles").select("email").eq("phone", phone).maybeSingle();
    if (!p?.email) throw new Error(generic);
    const client = createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: s, error } = await client.auth.signInWithPassword({ email: p.email, password: data.password });
    if (error || !s.session) {
      if (error?.message?.toLowerCase().includes("confirm")) throw new Error("Please verify your email before logging in.");
      throw new Error(generic);
    }
    return { access_token: s.session.access_token, refresh_token: s.session.refresh_token };
  });

export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await admin();
    await db.from("listings").update({ status: "removed" }).eq("seller_id", context.userId);
    await db.from("favorites").delete().eq("user_id", context.userId);
    await db.from("phone_otps").delete().eq("user_id", context.userId);
    await db.from("user_roles").delete().eq("user_id", context.userId);
    await db.from("profiles").delete().eq("id", context.userId);
    const { error } = await db.auth.admin.deleteUser(context.userId);
    if (error) throw new Error("Could not delete account.");
    return { ok: true };
  });
