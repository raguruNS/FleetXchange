export const formatINR = (n: number | null | undefined) =>
  n == null ? "—" : "₹" + Number(n).toLocaleString("en-IN");

export const formatKM = (n: number | null | undefined) =>
  n == null ? "" : Number(n).toLocaleString("en-IN") + " KM";

export const VEHICLE_BRANDS = [
  "Tata", "Ashok Leyland", "BharatBenz", "Eicher", "Volvo", "Scania", "Mahindra", "SML Isuzu", "Force", "MAN", "Other",
];
export const FUEL_TYPES = ["Diesel", "CNG", "Electric", "Petrol", "LNG", "Hybrid"];
export const TRANSMISSIONS = ["Manual", "Automatic", "AMT"];
export const BUS_AC = ["AC", "Non-AC"];
export const BUS_BODY = ["Seater", "Sleeper", "Semi-Sleeper", "School Bus", "City Bus", "Staff Bus", "Tourist Coach"];
export const TRUCK_BODY = ["Open Body", "Container", "Tipper", "Trailer", "Tanker", "Refrigerated", "Flatbed"];
export const AXLES = ["4x2", "6x2", "6x4", "8x2", "8x4", "10x2", "10x4", "12x2", "Single Axle", "Multi Axle"];

export const PART_CATEGORIES = [
  "Engine Parts", "Transmission", "Brakes", "Suspension", "Tyres & Wheels", "Batteries", "Electrical", "Lights",
  "AC & Cooling", "Body Parts", "Interior", "Glass & Mirrors", "Fuel System", "Filters", "Other",
];

export const VEHICLE_IMAGE_LABELS = ["Front", "Rear", "Left", "Right", "Interior", "Dashboard", "Engine", "Tyres", "Other"];
export const PART_IMAGE_LABELS = ["Part Front", "Part Back", "Part Number", "Packaging", "Close-up", "Condition", "Other"];

export const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi", "Goa", "Gujarat", "Haryana",
  "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
  "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
  "Uttar Pradesh", "Uttarakhand", "West Bengal", "Jammu & Kashmir", "Ladakh", "Puducherry", "Chandigarh",
];

export const REPORT_REASONS: { value: string; label: string }[] = [
  { value: "fake_vehicle", label: "Fake Vehicle" },
  { value: "fake_part", label: "Fake Spare Part" },
  { value: "incorrect_info", label: "Incorrect Information" },
  { value: "duplicate", label: "Duplicate" },
  { value: "fraud", label: "Fraud" },
  { value: "suspicious_seller", label: "Suspicious Seller" },
  { value: "wrong_compatibility", label: "Wrong Compatibility" },
  { value: "other", label: "Other" },
];

export const PASSWORD_RULES: { label: string; test: (s: string) => boolean }[] = [
  { label: "Minimum 8 characters", test: (s) => s.length >= 8 },
  { label: "At least 1 uppercase", test: (s) => /[A-Z]/.test(s) },
  { label: "At least 1 lowercase", test: (s) => /[a-z]/.test(s) },
  { label: "At least 1 number", test: (s) => /\d/.test(s) },
  { label: "At least 1 special character", test: (s) => /[^A-Za-z0-9]/.test(s) },
];
export const isStrongPassword = (s: string) => PASSWORD_RULES.every((r) => r.test(s));

/** Normalises an Indian mobile to +91XXXXXXXXXX, or null if invalid. */
export function normalizeIndianMobile(input: string): string | null {
  const digits = input.replace(/\D/g, "");
  const ten = digits.length === 12 && digits.startsWith("91") ? digits.slice(2) : digits.length === 11 && digits.startsWith("0") ? digits.slice(1) : digits;
  return /^[6-9]\d{9}$/.test(ten) ? "+91" + ten : null;
}
export const maskPhone = (p?: string | null) => (p ? p.replace(/^(\+91)(\d{5})(\d{5})$/, "$1 $2 $3") : "");

export type ListingImage = { url: string; path: string; label?: string };

export const vehicleLabel = (vt?: string | null, tier?: string | null) =>
  `${tier === "premium" ? "Premium " : ""}${vt === "bus" ? "Bus" : vt === "truck" ? "Truck" : ""}`;
