import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { ListingImage } from "./constants";

export const BUCKET = "listing-images";

/** Signs private storage paths (bucket is private; read policy allows signing). */
export function useSignedUrls(paths: (string | undefined | null)[]) {
  const clean = paths.filter(Boolean) as string[];
  const q = useQuery({
    queryKey: ["signed", clean],
    enabled: clean.length > 0,
    staleTime: 50 * 60 * 1000,
    queryFn: async () => {
      const { data } = await supabase.storage.from(BUCKET).createSignedUrls(clean, 3600);
      const m: Record<string, string> = {};
      (data ?? []).forEach((d) => { if (d.path && d.signedUrl) m[d.path] = d.signedUrl; });
      return m;
    },
  });
  return q.data ?? {};
}

export const imagesOf = (raw: unknown): ListingImage[] => (Array.isArray(raw) ? (raw as ListingImage[]) : []);

export async function uploadImage(userId: string, file: File) {
  if (!file.type.startsWith("image/")) throw new Error("Only image files are allowed.");
  if (file.size > 8 * 1024 * 1024) throw new Error("Each image must be under 8 MB.");
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
  if (error) throw new Error("Upload failed: " + error.message);
  return path;
}
