import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (!data) throw new Error("Forbidden");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

export const adminStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await assertAdmin(context);
    const c = async (q: any) => (await q).count ?? 0;
    const L = () => db.from("listings").select("id", { count: "exact", head: true });
    const [users, verified, buses, trucks, pBuses, pTrucks, parts, newParts, usedParts, active, sold, reports, pending] =
      await Promise.all([
        c(db.from("profiles").select("id", { count: "exact", head: true })),
        c(db.from("profiles").select("id", { count: "exact", head: true }).eq("phone_verified", true)),
        c(L().eq("vehicle_type", "bus")),
        c(L().eq("vehicle_type", "truck")),
        c(L().eq("vehicle_type", "bus").eq("tier", "premium")),
        c(L().eq("vehicle_type", "truck").eq("tier", "premium")),
        c(L().eq("kind", "part")),
        c(L().eq("kind", "part").eq("part_condition", "new")),
        c(L().eq("kind", "part").eq("part_condition", "used")),
        c(L().eq("status", "active")),
        c(L().eq("status", "sold")),
        c(db.from("reports").select("id", { count: "exact", head: true })),
        c(db.from("reports").select("id", { count: "exact", head: true }).eq("status", "pending")),
      ]);
    return { users, verified, buses, trucks, pBuses, pTrucks, parts, newParts, usedParts, active, sold, reports, pending };
  });

export const adminListUsers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ search: z.string().max(100).default("") }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await assertAdmin(context);
    let q = db.from("profiles").select("id, full_name, email, phone, location, phone_verified, is_blocked, created_at").order("created_at", { ascending: false }).limit(200);
    const s = data.search.trim().replace(/[,%()]/g, "");
    if (s) q = q.or(`full_name.ilike.%${s}%,email.ilike.%${s}%,phone.ilike.%${s}%`);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    const { data: admins } = await db.from("user_roles").select("user_id").eq("role", "admin");
    const adminIds = new Set((admins ?? []).map((a) => a.user_id));
    return (rows ?? []).map((r) => ({ ...r, is_admin: adminIds.has(r.id) }));
  });

export const adminSetBlocked = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ userId: z.string().uuid(), blocked: z.boolean() }).parse(d))
  .handler(async ({ data, context }) => {
    const db = await assertAdmin(context);
    if (data.userId === context.userId) throw new Error("You can't block yourself.");
    const { error } = await db.from("profiles").update({ is_blocked: data.blocked }).eq("id", data.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const adminListReports = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const db = await assertAdmin(context);
    const { data: reports } = await db.from("reports").select("*, listings(id, title, status, seller_id)").order("created_at", { ascending: false }).limit(300);
    const ids = [...new Set((reports ?? []).map((r) => r.reporter_id))];
    const { data: ps } = ids.length ? await db.from("profiles").select("id, full_name, email").in("id", ids) : { data: [] as any[] };
    const map = new Map((ps ?? []).map((p: any) => [p.id, p]));
    return (reports ?? []).map((r: any) => ({ ...r, reporter: map.get(r.reporter_id) ?? null }));
  });
