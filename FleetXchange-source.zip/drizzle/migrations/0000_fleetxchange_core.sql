
CREATE TYPE public.app_role AS ENUM ('admin','user');
CREATE TYPE public.listing_kind AS ENUM ('vehicle','part');
CREATE TYPE public.vehicle_type AS ENUM ('bus','truck');
CREATE TYPE public.listing_tier AS ENUM ('standard','premium');
CREATE TYPE public.part_condition AS ENUM ('new','used');
CREATE TYPE public.listing_status AS ENUM ('draft','active','sold','removed');
CREATE TYPE public.report_reason AS ENUM ('fake_vehicle','fake_part','incorrect_info','duplicate','fraud','suspicious_seller','wrong_compatibility','other');
CREATE TYPE public.report_status AS ENUM ('pending','under_review','resolved','rejected');

-- Profiles
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  full_name text NOT NULL DEFAULT '',
  email text,
  phone text UNIQUE,
  location text,
  avatar_url text,
  bio text,
  phone_verified boolean NOT NULL DEFAULT false,
  show_phone boolean NOT NULL DEFAULT true,
  email_notifications boolean NOT NULL DEFAULT true,
  is_blocked boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO authenticated;
GRANT UPDATE (full_name, location, avatar_url, bio, show_phone, email_notifications) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Roles
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.can_transact(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND phone_verified AND NOT is_blocked)
$$;

CREATE POLICY "own roles readable" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "own profile readable" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- New user trigger
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, phone, location)
  VALUES (NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name',''),
    NEW.email,
    NULLIF(NEW.raw_user_meta_data->>'phone',''),
    NEW.raw_user_meta_data->>'location');
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.sync_profile_email()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.email IS DISTINCT FROM OLD.email THEN
    UPDATE public.profiles SET email = NEW.email WHERE id = NEW.id;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER on_auth_user_email_updated AFTER UPDATE OF email ON auth.users FOR EACH ROW EXECUTE FUNCTION public.sync_profile_email();

-- Public seller view
CREATE OR REPLACE FUNCTION public.get_seller(_id uuid)
RETURNS TABLE (id uuid, full_name text, location text, avatar_url text, bio text, created_at timestamptz, email_verified boolean, phone_verified boolean, phone text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT p.id, p.full_name, p.location, p.avatar_url, p.bio, p.created_at,
    (u.email_confirmed_at IS NOT NULL), p.phone_verified,
    CASE WHEN auth.uid() IS NOT NULL AND p.show_phone AND p.phone_verified THEN p.phone ELSE NULL END
  FROM public.profiles p JOIN auth.users u ON u.id = p.id
  WHERE p.id = _id AND NOT p.is_blocked
$$;
GRANT EXECUTE ON FUNCTION public.get_seller(uuid) TO anon, authenticated;

-- OTP (server only)
CREATE TABLE public.phone_otps (
  user_id uuid PRIMARY KEY,
  phone text NOT NULL,
  code_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  attempts int NOT NULL DEFAULT 0,
  last_sent_at timestamptz NOT NULL DEFAULT now(),
  window_start timestamptz NOT NULL DEFAULT now(),
  sends_in_window int NOT NULL DEFAULT 1
);
GRANT ALL ON public.phone_otps TO service_role;
ALTER TABLE public.phone_otps ENABLE ROW LEVEL SECURITY;

-- Listings
CREATE TABLE public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL DEFAULT auth.uid(),
  kind public.listing_kind NOT NULL,
  vehicle_type public.vehicle_type,
  tier public.listing_tier NOT NULL DEFAULT 'standard',
  part_condition public.part_condition,
  part_category text,
  title text NOT NULL,
  brand text,
  model text,
  mfg_year int,
  reg_year int,
  price bigint NOT NULL CHECK (price >= 0),
  km int,
  fuel text,
  transmission text,
  owners int,
  specs jsonb NOT NULL DEFAULT '{}'::jsonb,
  part_number text,
  compat_vehicle_type text,
  compat_brand text,
  compat_model text,
  compat_year text,
  quantity int,
  state text,
  city text,
  area text,
  description text,
  images jsonb NOT NULL DEFAULT '[]'::jsonb,
  status public.listing_status NOT NULL DEFAULT 'active',
  suspicious boolean NOT NULL DEFAULT false,
  removed_by_admin boolean NOT NULL DEFAULT false,
  sold_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX listings_active_idx ON public.listings (status, kind, created_at DESC);
CREATE INDEX listings_seller_idx ON public.listings (seller_id);
CREATE INDEX listings_price_idx ON public.listings (price);
GRANT SELECT ON public.listings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.listings TO authenticated;
GRANT ALL ON public.listings TO service_role;
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "active listings public" ON public.listings FOR SELECT TO anon, authenticated USING (status = 'active');
CREATE POLICY "owner reads own" ON public.listings FOR SELECT TO authenticated USING (seller_id = auth.uid());
CREATE POLICY "admin reads all" ON public.listings FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "verified insert" ON public.listings FOR INSERT TO authenticated WITH CHECK (seller_id = auth.uid() AND public.can_transact(auth.uid()));
CREATE POLICY "owner update" ON public.listings FOR UPDATE TO authenticated USING (seller_id = auth.uid() AND public.can_transact(auth.uid())) WITH CHECK (seller_id = auth.uid());
CREATE POLICY "admin update" ON public.listings FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.protect_listing_fields()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  NEW.updated_at := now();
  IF NOT public.has_role(auth.uid(),'admin') THEN
    IF TG_OP = 'INSERT' THEN
      NEW.suspicious := false; NEW.removed_by_admin := false;
    ELSE
      NEW.suspicious := OLD.suspicious;
      NEW.removed_by_admin := OLD.removed_by_admin;
      NEW.seller_id := OLD.seller_id;
      IF OLD.removed_by_admin THEN NEW.status := OLD.status; END IF;
    END IF;
  END IF;
  IF NEW.status = 'sold' AND (TG_OP = 'INSERT' OR OLD.status <> 'sold') THEN NEW.sold_at := now(); END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER listings_protect BEFORE INSERT OR UPDATE ON public.listings FOR EACH ROW EXECUTE FUNCTION public.protect_listing_fields();

-- Favorites
CREATE TABLE public.favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, listing_id)
);
GRANT SELECT, INSERT, DELETE ON public.favorites TO authenticated;
GRANT ALL ON public.favorites TO service_role;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own favorites" ON public.favorites FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- Conversations & messages
CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  buyer_id uuid NOT NULL DEFAULT auth.uid(),
  seller_id uuid NOT NULL,
  last_message_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (listing_id, buyer_id)
);
GRANT SELECT, INSERT, UPDATE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "participants read conv" ON public.conversations FOR SELECT TO authenticated USING (auth.uid() IN (buyer_id, seller_id));
CREATE POLICY "buyer starts conv" ON public.conversations FOR INSERT TO authenticated WITH CHECK (
  buyer_id = auth.uid() AND buyer_id <> seller_id AND public.can_transact(auth.uid())
  AND EXISTS (SELECT 1 FROM public.listings l WHERE l.id = listing_id AND l.seller_id = conversations.seller_id AND l.status = 'active'));

CREATE OR REPLACE FUNCTION public.is_participant(_conv uuid, _user uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.conversations WHERE id = _conv AND _user IN (buyer_id, seller_id))
$$;

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL DEFAULT auth.uid(),
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  created_at timestamptz NOT NULL DEFAULT now(),
  read_at timestamptz
);
CREATE INDEX messages_conv_idx ON public.messages (conversation_id, created_at);
GRANT SELECT, INSERT ON public.messages TO authenticated;
GRANT UPDATE (read_at) ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "participants read msgs" ON public.messages FOR SELECT TO authenticated USING (public.is_participant(conversation_id, auth.uid()));
CREATE POLICY "participants send" ON public.messages FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid() AND public.is_participant(conversation_id, auth.uid()) AND public.can_transact(auth.uid()));
CREATE POLICY "recipient marks read" ON public.messages FOR UPDATE TO authenticated USING (sender_id <> auth.uid() AND public.is_participant(conversation_id, auth.uid()));

CREATE OR REPLACE FUNCTION public.bump_conversation()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN UPDATE public.conversations SET last_message_at = NEW.created_at WHERE id = NEW.conversation_id; RETURN NEW; END $$;
CREATE TRIGGER messages_bump AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION public.bump_conversation();

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

-- Conversation list with counterpart names
CREATE OR REPLACE FUNCTION public.my_conversations()
RETURNS TABLE (id uuid, listing_id uuid, listing_title text, listing_image text, other_id uuid, other_name text, other_avatar text, last_message text, last_message_at timestamptz, unread bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT c.id, c.listing_id, l.title, l.images->0->>'url',
    o.id, o.full_name, o.avatar_url,
    (SELECT m.body FROM public.messages m WHERE m.conversation_id = c.id ORDER BY m.created_at DESC LIMIT 1),
    c.last_message_at,
    (SELECT count(*) FROM public.messages m WHERE m.conversation_id = c.id AND m.sender_id <> auth.uid() AND m.read_at IS NULL)
  FROM public.conversations c
  JOIN public.listings l ON l.id = c.listing_id
  JOIN public.profiles o ON o.id = CASE WHEN c.buyer_id = auth.uid() THEN c.seller_id ELSE c.buyer_id END
  WHERE auth.uid() IN (c.buyer_id, c.seller_id)
  ORDER BY c.last_message_at DESC
$$;
GRANT EXECUTE ON FUNCTION public.my_conversations() TO authenticated;

-- Reports
CREATE TABLE public.reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id uuid NOT NULL REFERENCES public.listings(id) ON DELETE CASCADE,
  reporter_id uuid NOT NULL DEFAULT auth.uid(),
  reason public.report_reason NOT NULL,
  details text CHECK (details IS NULL OR char_length(details) <= 1000),
  status public.report_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "report insert" ON public.reports FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid() AND status = 'pending');
CREATE POLICY "report read" ON public.reports FOR SELECT TO authenticated USING (reporter_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "report admin update" ON public.reports FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- First admin bootstrap
CREATE OR REPLACE FUNCTION public.claim_first_admin()
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN RETURN false; END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (auth.uid(), 'admin');
  RETURN true;
END $$;
GRANT EXECUTE ON FUNCTION public.claim_first_admin() TO authenticated;

-- Storage policies
CREATE POLICY "listing images public read" ON storage.objects FOR SELECT USING (bucket_id = 'listing-images');
CREATE POLICY "users upload own images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "users delete own images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'listing-images' AND (storage.foldername(name))[1] = auth.uid()::text);
